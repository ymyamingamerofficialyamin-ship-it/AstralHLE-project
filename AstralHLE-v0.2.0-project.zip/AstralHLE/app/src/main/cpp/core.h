// AstralHLE core: loader, HLE function table and run loop.
#pragma once
#include "cpu.h"
#include "macho.h"
#include <functional>
#include <map>
#include <string>
#include <unordered_map>
#include <vector>

namespace astral {

class Core;
using HleFn = std::function<void(Core&)>;

class Core {
 public:
  Core();

  Memory mem;
  Cpu cpu;
  MachInfo info;
  std::string log;
  std::string device_model = "iPhone1,2";   // reported by sysctl hw.machine
  std::string bundle_dir;                   // host folder with the extracted .app (optional)
  std::string app_name = "game";

  bool exited = false;
  int exit_code = 0;
  std::string stop_reason;
  std::vector<std::string> recent_calls;    // last HLE calls (for the report)
  uint64_t hle_calls = 0;

  std::unordered_map<std::string, HleFn> fns;

  bool load_file(const std::string& path);
  // Loads, runs for up to max_insns guest instructions and returns a human readable report.
  std::string run_report(const std::string& path, uint64_t max_insns);

  // ---- helpers for HLE functions
  uint32_t arg(int i) { return i < 4 ? cpu.r[i] : mem.read32(cpu.r[13] + 4 * (i - 4)); }
  void ret(uint32_t v) { cpu.r[0] = v; }
  void ret64(uint64_t v) { cpu.r[0] = (uint32_t)v; cpu.r[1] = (uint32_t)(v >> 32); }
  uint32_t guest_alloc(uint32_t size);
  void guest_free(uint32_t p);
  uint32_t guest_size(uint32_t p) { return p ? mem.read32(p - 8) : 0; }
  uint32_t alloc_cstr(const std::string& s);
  uint32_t call_guest(uint32_t addr, std::initializer_list<uint32_t> args);
  void request_exit(int code, const std::string& why) { exited = true; exit_code = code; if (stop_reason.empty()) stop_reason = why; }
  std::string format_c(uint32_t fmt, int first_slot, uint32_t va_list_ptr, bool use_va);
  void out(const std::string& s);   // game output (printf/puts/NSLog)

 private:
  std::vector<std::string> trap_names_{""};
  std::unordered_map<std::string, uint32_t> trap_ids_;
  std::unordered_map<std::string, uint32_t> data_syms_;
  uint32_t heap_ptr_ = 0x40000000;
  uint32_t data_ptr_ = 0x60000000;
  std::map<uint32_t, std::vector<uint32_t>> free_lists_;
  uint32_t sp_top_ = 0x30000000;
  uint32_t argv_ptr_ = 0, envp_ptr_ = 0, apple_ptr_ = 0;
  uint32_t trap_addr(const std::string& name);
  uint32_t symbol_addr(const std::string& name);
  uint32_t data_symbol(const std::string& name, bool& is_data);
  void bind_all();
  void setup_stack();
  Stop pump(uint64_t limit_icount);
  bool dispatch_trap();
  friend void install_hle(Core&);
};

void install_hle(Core& c);

}  // namespace astral
