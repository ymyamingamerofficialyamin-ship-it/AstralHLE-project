#include <jni.h>
#include <string>
#include "core.h"

extern "C" JNIEXPORT jstring JNICALL
Java_com_astralhle_app_AstralCore_run(JNIEnv* env, jclass, jstring execPath, jstring deviceModel, jlong maxInsns) {
  const char* path = env->GetStringUTFChars(execPath, nullptr);
  const char* dev = env->GetStringUTFChars(deviceModel, nullptr);
  std::string report;
  {
    astral::Core core;
    core.device_model = dev;
    report = core.run_report(path, (uint64_t)maxInsns);
  }
  env->ReleaseStringUTFChars(execPath, path);
  env->ReleaseStringUTFChars(deviceModel, dev);
  return env->NewStringUTF(report.c_str());
}
