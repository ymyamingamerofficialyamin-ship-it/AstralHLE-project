// AstralHLE core: paged guest memory (32-bit address space).
#pragma once
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>

namespace astral {

class Memory {
 public:
  Memory() : l1_(1u << 20, nullptr) {}
  ~Memory() { for (uint8_t* p : pages_) delete[] p; }
  Memory(const Memory&) = delete;
  Memory& operator=(const Memory&) = delete;

  bool fault = false;
  uint32_t fault_addr = 0;
  bool fault_write = false;

  // Pages inside these ranges are created on first touch (stack, heap, mmap area).
  void add_auto(uint32_t lo, uint32_t hi) { auto_.push_back({lo, hi}); }

  void map(uint32_t addr, uint32_t size) {
    if (!size) return;
    uint32_t first = addr >> 12, last = (uint32_t)(((uint64_t)addr + size - 1) >> 12);
    for (uint32_t i = first; i <= last; i++) make(i);
  }
  bool mapped(uint32_t addr) const { return l1_[addr >> 12] != nullptr; }

  uint8_t read8(uint32_t a) { uint8_t* p = pg(a, false); return p ? p[a & 0xfff] : 0; }
  uint16_t read16(uint32_t a) {
    if ((a & 0xfff) <= 0xffe) { uint8_t* p = pg(a, false); if (!p) return 0; uint16_t v; memcpy(&v, p + (a & 0xfff), 2); return v; }
    return read8(a) | (read8(a + 1) << 8);
  }
  uint32_t read32(uint32_t a) {
    if ((a & 0xfff) <= 0xffc) { uint8_t* p = pg(a, false); if (!p) return 0; uint32_t v; memcpy(&v, p + (a & 0xfff), 4); return v; }
    return read8(a) | (read8(a + 1) << 8) | (read8(a + 2) << 16) | ((uint32_t)read8(a + 3) << 24);
  }
  void write8(uint32_t a, uint8_t v) { uint8_t* p = pg(a, true); if (p) p[a & 0xfff] = v; }
  void write16(uint32_t a, uint16_t v) {
    if ((a & 0xfff) <= 0xffe) { uint8_t* p = pg(a, true); if (p) memcpy(p + (a & 0xfff), &v, 2); return; }
    write8(a, v & 0xff); write8(a + 1, v >> 8);
  }
  void write32(uint32_t a, uint32_t v) {
    if ((a & 0xfff) <= 0xffc) { uint8_t* p = pg(a, true); if (p) memcpy(p + (a & 0xfff), &v, 4); return; }
    for (int i = 0; i < 4; i++) write8(a + i, (v >> (8 * i)) & 0xff);
  }

  // Bulk helpers used by the loader and the HLE layer (create pages as needed).
  void write_bytes(uint32_t a, const void* data, size_t n) {
    const uint8_t* s = (const uint8_t*)data;
    while (n) {
      uint32_t off = a & 0xfff; size_t chunk = std::min<size_t>(n, 4096 - off);
      make(a >> 12); memcpy(l1_[a >> 12] + off, s, chunk); a += (uint32_t)chunk; s += chunk; n -= chunk;
    }
  }
  void read_bytes(uint32_t a, void* out, size_t n) {
    uint8_t* d = (uint8_t*)out;
    for (size_t i = 0; i < n; i++) d[i] = read8(a + (uint32_t)i);
  }
  void fill(uint32_t a, uint8_t v, size_t n) { for (size_t i = 0; i < n; i++) write8(a + (uint32_t)i, v); }
  std::string cstring(uint32_t a, size_t max = 4096) {
    std::string s;
    for (size_t i = 0; i < max; i++) { uint8_t c = read8(a + (uint32_t)i); if (!c) break; s.push_back((char)c); }
    return s;
  }

 private:
  struct Range { uint32_t lo, hi; };
  std::vector<uint8_t*> l1_;
  std::vector<uint8_t*> pages_;
  std::vector<Range> auto_;

  uint8_t* make(uint32_t idx) {
    uint8_t* p = l1_[idx];
    if (!p) { p = new uint8_t[4096](); l1_[idx] = p; pages_.push_back(p); }
    return p;
  }
  bool in_auto(uint32_t a) const { for (auto& r : auto_) if (a >= r.lo && a < r.hi) return true; return false; }
  uint8_t* pg(uint32_t a, bool write) {
    uint8_t* p = l1_[a >> 12];
    if (p) return p;
    if (in_auto(a)) return make(a >> 12);
    if (!fault) { fault = true; fault_addr = a; fault_write = write; }
    return nullptr;
  }
};

}  // namespace astral
