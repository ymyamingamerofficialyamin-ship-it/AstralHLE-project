package com.astralhle.app

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.*
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

/** Settings with liquid glass panels. */
class SettingsView(ctx: Context, private val onClose: () -> Unit) : FrameLayout(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val accent = Color.rgb(130, 195, 255)
    private val content = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private val scroll = ScrollView(ctx)

    private val wall = object : View(ctx) {
        private val p = Paint(Paint.FILTER_BITMAP_FLAG)
        private val dim = Paint().apply { color = Color.argb(96, 0, 0, 14) }
        override fun onDraw(c: Canvas) {
            c.drawBitmap(Wallpaper.cover(context, width, height), 0f, 0f, p); c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
        }
    }

    private inner class GlassCard(ctx: Context) : LinearLayout(ctx) {
        init { orientation = VERTICAL; setWillNotDraw(false) }
        override fun onDraw(c: Canvas) { Glass.panel(c, this, RectF(0f, 0f, width.toFloat(), height.toFloat()), 26 * d, 38) }
    }

    private inner class BackButton(ctx: Context) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 2.4f * d; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        override fun onDraw(c: Canvas) {
            val r = RectF(0f, 0f, width.toFloat(), height.toFloat())
            Glass.panel(c, this, r, width / 2f, 44)
            val cx = width / 2f; val cy = height / 2f
            val path = Path(); path.moveTo(cx + 3 * d, cy - 8 * d); path.lineTo(cx - 4 * d, cy); path.lineTo(cx + 3 * d, cy + 8 * d); c.drawPath(path, p)
        }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (e.actionMasked == MotionEvent.ACTION_UP) { performClick(); onClose() }
            return true
        }
    }

    private inner class Segmented(ctx: Context, val options: List<String>, var selected: Int, val onSelect: (Int) -> Unit) : View(ctx) {
        private val bgP = Paint(Paint.ANTI_ALIAS_FLAG)
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1f * d }
        private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; textSize = 13f * ctx.resources.displayMetrics.scaledDensity }
        override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(MeasureSpec.getSize(w), (40 * d).toInt()) }
        override fun onDraw(c: Canvas) {
            val r = RectF(0f, 0f, width.toFloat(), height.toFloat())
            bgP.color = Color.argb(70, 0, 0, 0); c.drawRoundRect(r, height / 2f, height / 2f, bgP)
            line.color = Color.argb(70, 255, 255, 255); c.drawRoundRect(r, height / 2f, height / 2f, line)
            val sw = width.toFloat() / options.size
            val s = RectF(sw * selected + 3 * d, 3 * d, sw * (selected + 1) - 3 * d, height - 3 * d)
            bgP.color = Color.argb(95, 255, 255, 255); c.drawRoundRect(s, s.height() / 2f, s.height() / 2f, bgP)
            line.color = Color.argb(150, 255, 255, 255); c.drawRoundRect(s, s.height() / 2f, s.height() / 2f, line)
            options.forEachIndexed { i, o -> c.drawText(o, sw * (i + 0.5f), height / 2f + 4.5f * d, text) }
        }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (e.actionMasked == MotionEvent.ACTION_UP) {
                val i = (e.x / (width.toFloat() / options.size)).toInt().coerceIn(0, options.size - 1)
                if (i != selected) { selected = i; invalidate(); onSelect(i) }
                performClick()
            }
            return true
        }
    }

    init {
        addView(wall, LayoutParams(-1, -1))
        content.setPadding((16 * d).toInt(), (104 * d).toInt(), (16 * d).toInt(), (46 * d).toInt())
        scroll.addView(content, ViewGroup.LayoutParams(-1, -2)); scroll.isVerticalScrollBarEnabled = false
        addView(scroll, LayoutParams(-1, -1))
        // soft fade behind the title so the content scrolls out smoothly
        addView(object : View(ctx) {
            override fun onDraw(c: Canvas) {
                val p = Paint(); p.shader = LinearGradient(0f, 0f, 0f, height.toFloat(), Color.argb(225, 4, 4, 14), Color.argb(0, 4, 4, 14), Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), p)
            }
        }, LayoutParams(-1, (118 * d).toInt()))
        val title = TextView(ctx).apply { text = "Settings"; setTextColor(Color.WHITE); textSize = 18f; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); gravity = Gravity.CENTER }
        addView(title, LayoutParams(-1, (44 * d).toInt()).apply { topMargin = (34 * d).toInt() })
        addView(BackButton(ctx), LayoutParams((44 * d).toInt(), (44 * d).toInt()).apply { topMargin = (34 * d).toInt(); leftMargin = (16 * d).toInt() })
        build()
    }

    // ---------------------------------------------------------------- row helpers
    private fun header(t: String) = content.addView(TextView(context).apply {
        text = t; setTextColor(Color.argb(160, 255, 255, 255)); textSize = 12.5f; letterSpacing = 0.06f
        setPadding((10 * d).toInt(), (22 * d).toInt(), 0, (8 * d).toInt())
    })

    private fun footnote(t: String) = content.addView(TextView(context).apply {
        text = t; setTextColor(Color.argb(130, 255, 255, 255)); textSize = 12f
        setPadding((10 * d).toInt(), (8 * d).toInt(), (10 * d).toInt(), 0)
    })

    private fun card(rows: List<View>) {
        val card = GlassCard(context)
        rows.forEachIndexed { i, r ->
            card.addView(r, LinearLayout.LayoutParams(-1, -2))
            if (i < rows.size - 1) card.addView(View(context).apply { setBackgroundColor(Color.argb(34, 255, 255, 255)) },
                LinearLayout.LayoutParams(-1, 1).apply { leftMargin = (16 * d).toInt() })
        }
        content.addView(card, LinearLayout.LayoutParams(-1, -2))
    }

    private fun baseRow(title: String, sub: String?, right: View?, click: (() -> Unit)?, dimmed: Boolean = false): LinearLayout {
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding((16 * d).toInt(), (13 * d).toInt(), (16 * d).toInt(), (13 * d).toInt())
        }
        val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(context).apply { text = title; textSize = 16f; setTextColor(if (dimmed) Color.argb(110, 255, 255, 255) else Color.WHITE) })
        if (sub != null) col.addView(TextView(context).apply { text = sub; textSize = 12f; setTextColor(Color.argb(150, 255, 255, 255)) })
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        if (right != null) row.addView(right)
        if (click != null) row.setOnClickListener { click() }
        return row
    }

    private fun checkRow(title: String, sub: String?, selected: Boolean, enabled: Boolean = true, click: () -> Unit): View =
        baseRow(title, sub, if (selected) TextView(context).apply { text = "\u2713"; textSize = 18f; setTextColor(accent) } else null, click, !enabled)

    private fun switchRow(title: String, key: String, def: Boolean, rebuild: Boolean = false): View {
        val sw = Switch(context).apply {
            isChecked = Prefs.getBool(context, key, def)
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            trackTintList = ColorStateList(states, intArrayOf(Color.rgb(52, 199, 89), Color.argb(90, 255, 255, 255)))
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            setOnCheckedChangeListener { _, v -> Prefs.setBool(context, key, v); if (rebuild) build() }
        }
        return baseRow(title, null, sw, null)
    }

    private fun segRow(title: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit): View {
        val box = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; setPadding((16 * d).toInt(), (13 * d).toInt(), (16 * d).toInt(), (14 * d).toInt()) }
        box.addView(TextView(context).apply { text = title; textSize = 16f; setTextColor(Color.WHITE) })
        box.addView(Segmented(context, options, selected, onSelect), LinearLayout.LayoutParams(-1, -2).apply { topMargin = (10 * d).toInt() })
        return box
    }

    private fun valueRow(title: String, value: String, click: () -> Unit): View =
        baseRow(title, null, TextView(context).apply { text = "$value  \u25be"; textSize = 15f; setTextColor(accent) }, click)

    private fun choose(title: String, items: List<String>, selected: Int, onPick: (Int) -> Unit) {
        AlertDialog.Builder(context, android.R.style.Theme_Material_Dialog_Alert).setTitle(title)
            .setSingleChoiceItems(items.toTypedArray(), selected) { dlg, which -> onPick(which); dlg.dismiss(); build() }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------------------------------------------------------------- screen content
    fun build() {
        val keep = scroll.scrollY
        content.removeAllViews()
        val c = context
        val dem = "Very demanding. Recommended for high-end devices only"
        val sc = Prefs.scale(c)
        header("QUALITY")
        card(listOf(
            checkRow("Original (default)", "The resolution the game ran at on the original iPhone", sc == 1) { Prefs.setInt(c, "scale", 1); build() },
            checkRow("2x", null, sc == 2) { Prefs.setInt(c, "scale", 2); build() },
            checkRow("3x", null, sc == 3) { Prefs.setInt(c, "scale", 3); build() },
            checkRow("4x", dem, sc == 4) { Prefs.setInt(c, "scale", 4); build() },
            checkRow("5x", dem, sc == 5) { Prefs.setInt(c, "scale", 5); build() }))
        footnote("Higher values make games sharper but need a faster GPU and more memory.")

        header("DISPLAY")
        card(listOf(
            segRow("Display mode", listOf("Minimal", "Full"), if (Prefs.displayFull(c)) 1 else 0) { Prefs.setBool(c, "displayFull", it == 1) },
            switchRow("FPS counter", "fps", false),
            segRow("Screen corner", listOf("Top left", "Top right", "Bottom right", "Bottom left"), Prefs.fpsCorner(c)) { Prefs.setInt(c, "fpsCorner", it) },
            switchRow("Trace GL errors", "traceGl", false),
            switchRow("Lock screen", "lockScreen", true)))
        footnote("Minimal keeps the original iPhone aspect ratio. Full fills the whole screen. Trace GL errors writes OpenGL errors to the log for debugging.")

        header("GRAPHICS")
        val b = Prefs.backend(c); val vk = GpuPolicy.vulkanAvailable(c)
        card(listOf(
            checkRow("Auto (recommended)", "OpenGL ES on low-end devices, Vulkan on high-end devices", b == Backend.AUTO) { Prefs.setStr(c, "backend", "AUTO"); build() },
            checkRow("OpenGL ES", null, b == Backend.OPENGL) { Prefs.setStr(c, "backend", "OPENGL"); build() },
            checkRow("Vulkan", if (vk) null else "Not supported on this device", b == Backend.VULKAN, vk) {
                if (vk) { Prefs.setStr(c, "backend", "VULKAN"); build() } else Toast.makeText(c, "Vulkan 1.1 is not available on this device", Toast.LENGTH_SHORT).show()
            }))
        footnote("Currently using: " + (if (GpuPolicy.resolve(c) == Backend.VULKAN) "Vulkan" else "OpenGL ES") + ".")

        header("EMULATION")
        card(listOf(
            switchRow("Cheat Engine", "cheat", false),
            switchRow("Network access", "network", false),
            switchRow("Local Game Center sign-in", "localGc", false),
            switchRow("Use analog sticks for tilt controls", "analogTilt", true)))

        header("DEVICE")
        card(listOf(
            valueRow("Device model", Options.deviceNames[Prefs.deviceIndex(c)]) { choose("Device model", Options.deviceNames, Prefs.deviceIndex(c)) { Prefs.setInt(c, "device", it) } },
            valueRow("Language", Options.languages[Prefs.languageIndex(c)]) { choose("Language", Options.languages, Prefs.languageIndex(c)) { Prefs.setInt(c, "language", it) } }))
        footnote("Games only show the languages they contain. If a language is missing in the game, it falls back to its default.")

        header("TIME & DATE")
        val auto = Prefs.getBool(c, "timeAuto", true)
        card(listOf(
            switchRow("Set automatically", "timeAuto", true, rebuild = true),
            segRow("Time format", listOf("12-hour", "24-hour"), if (Clock.is24(c)) 1 else 0) { Prefs.setBool(c, "time24", it == 1) },
            baseRow("Set date & time", null, TextView(c).apply { text = Clock.fullText(c); textSize = 14f; setTextColor(if (auto) Color.argb(110, 255, 255, 255) else accent) },
                { pickDateTime(auto) }, auto)))
        footnote("This only changes the time shown inside AstralHLE. Your phone's real clock is not touched.")

        content.addView(TextView(c).apply {
            text = "AstralHLE"; setTextColor(Color.argb(210, 255, 255, 255)); textSize = 15f; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); gravity = Gravity.CENTER
            setPadding(0, (34 * d).toInt(), 0, (2 * d).toInt())
        }, LinearLayout.LayoutParams(-1, -2))
        content.addView(TextView(c).apply {
            text = "\u00a9 Copyright reserved by 7.0Transformers Editz"; setTextColor(Color.argb(130, 255, 255, 255)); textSize = 11f; gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))
        scroll.post { scroll.scrollTo(0, keep) }
    }

    private fun pickDateTime(auto: Boolean) {
        val c = context
        if (auto) { Toast.makeText(c, "Turn off Set automatically first", Toast.LENGTH_SHORT).show(); return }
        val cal = Calendar.getInstance().apply { timeInMillis = Clock.now(c) }
        val theme = android.R.style.Theme_Material_Dialog_Alert
        DatePickerDialog(c, theme, { _, y, m, day ->
            TimePickerDialog(c, theme, { _, hh, mm ->
                val chosen = Calendar.getInstance().apply { set(y, m, day, hh, mm, 0) }.timeInMillis
                Prefs.setLong(c, "timeOffset", chosen - System.currentTimeMillis()); build()
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), Clock.is24(c)).show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }
}
