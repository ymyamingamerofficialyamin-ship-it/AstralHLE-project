package com.astralhle.app

/** Bridge to the native emulation core (C++). */
object AstralCore {
    private var loaded = false
    private var loadError: String? = null

    @JvmStatic external fun run(execPath: String, deviceModel: String, maxInsns: Long): String

    @Synchronized
    fun ensureLoaded(): Boolean {
        if (loaded) return true
        return try { System.loadLibrary("astralcore"); loaded = true; true } catch (t: Throwable) { loadError = t.message; false }
    }

    fun error(): String = loadError ?: "unknown error"
}
