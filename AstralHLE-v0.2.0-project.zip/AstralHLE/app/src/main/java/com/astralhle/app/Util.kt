package com.astralhle.app

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.BatteryManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Backend { AUTO, OPENGL, VULKAN }

/** Choices shown in the Device model and Language settings. */
object Options {
    val deviceNames = listOf("Default", "iPhone", "iPhone 3G", "iPhone 3GS", "iPhone 4")
    val deviceIds = listOf("iPhone2,1", "iPhone1,1", "iPhone1,2", "iPhone2,1", "iPhone3,1")
    val languages = listOf(
        "Default (English)", "English", "普通话", "हिन्दी", "Español", "Français", "العربية", "বাংলা", "Русский", "Português",
        "اردو", "Bahasa Indonesia", "Deutsch", "日本語", "मराठी", "తెలుగు", "Türkçe", "தமிழ்", "粵語", "Tiếng Việt",
        "한국어", "Italiano", "Basa Jawa", "فارسی", "ગુજરાતી", "Polski", "Українська", "Bahasa Melayu", "ಕನ್ನಡ", "ଓଡ଼ିଆ",
        "Română", "Português brasileiro"
    )
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("astral", Context.MODE_PRIVATE)
    fun getInt(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    fun setInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun getBool(c: Context, k: String, d: Boolean) = sp(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()
    fun getLong(c: Context, k: String, d: Long) = sp(c).getLong(k, d)
    fun setLong(c: Context, k: String, v: Long) = sp(c).edit().putLong(k, v).apply()
    fun getStr(c: Context, k: String, d: String?) = sp(c).getString(k, d)
    fun setStr(c: Context, k: String, v: String?) = sp(c).edit().putString(k, v).apply()

    // Quality: 1 = original game resolution, 2..5 = multiplier
    fun scale(c: Context) = getInt(c, "scale", 1)
    fun fps(c: Context) = getBool(c, "fps", false)
    fun fpsCorner(c: Context) = getInt(c, "fpsCorner", 1)          // 0 TL, 1 TR, 2 BR, 3 BL
    fun displayFull(c: Context) = getBool(c, "displayFull", false) // false = Minimal (original aspect ratio)
    fun lockScreen(c: Context) = getBool(c, "lockScreen", true)
    fun backend(c: Context): Backend = try { Backend.valueOf(getStr(c, "backend", "AUTO")!!) } catch (e: Exception) { Backend.AUTO }
    fun deviceIndex(c: Context) = getInt(c, "device", 0)
    fun languageIndex(c: Context) = getInt(c, "language", 0)
    fun gamesJson(c: Context) = getStr(c, "games", "[]")!!
    fun recentId(c: Context) = getStr(c, "recent", null)
}

object GpuPolicy {
    fun vulkanAvailable(c: Context): Boolean =
        Build.VERSION.SDK_INT >= 24 && c.packageManager.hasSystemFeature(PackageManager.FEATURE_VULKAN_HARDWARE_VERSION, 0x401000)

    fun totalRamGb(c: Context): Double {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        return mi.totalMem / (1024.0 * 1024.0 * 1024.0)
    }

    fun isHighEnd(c: Context): Boolean {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return Build.VERSION.SDK_INT >= 29 && !am.isLowRamDevice && totalRamGb(c) >= 5.5
    }

    /** What the emulator really uses. Auto picks Vulkan only on capable, high-end, Android 10+ phones. */
    fun resolve(c: Context): Backend = when (Prefs.backend(c)) {
        Backend.OPENGL -> Backend.OPENGL
        Backend.VULKAN -> if (vulkanAvailable(c)) Backend.VULKAN else Backend.OPENGL
        Backend.AUTO -> if (vulkanAvailable(c) && isHighEnd(c)) Backend.VULKAN else Backend.OPENGL
    }
}

/** Time shown inside AstralHLE (can be set by hand, never changes the real phone clock). */
object Clock {
    fun now(c: Context): Long =
        if (Prefs.getBool(c, "timeAuto", true)) System.currentTimeMillis() else System.currentTimeMillis() + Prefs.getLong(c, "timeOffset", 0L)
    fun is24(c: Context) = Prefs.getBool(c, "time24", android.text.format.DateFormat.is24HourFormat(c))
    fun timeText(c: Context): String = SimpleDateFormat(if (is24(c)) "HH:mm" else "h:mm", Locale.getDefault()).format(Date(now(c)))
    fun dateText(c: Context): String = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date(now(c)))
    fun fullText(c: Context): String = SimpleDateFormat(if (is24(c)) "d MMM yyyy, HH:mm" else "d MMM yyyy, h:mm a", Locale.getDefault()).format(Date(now(c)))
}

object BatteryInfo {
    /** Returns (percent, charging). */
    fun read(c: Context): Pair<Int, Boolean> {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return Pair(100, false)
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else 100
        return Pair(pct, st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL)
    }
}
