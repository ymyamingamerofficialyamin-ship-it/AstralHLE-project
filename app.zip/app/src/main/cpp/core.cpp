#include "core.h"
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>

namespace astral {

Core::Core() {
  cpu.mem = &mem;
  mem.add_auto(0x2FF00000u, 0x30000000u);   // main thread stack
  mem.add_auto(0x40000000u, 0x60000000u);   // heap
  mem.add_auto(0x70000000u, 0xA0000000u);   // mmap area
  install_hle(*this);
}

static std::string hex(uint32_t v) { char b[16]; snprintf(b, sizeof b, "0x%08x", v); return b; }

uint32_t Core::guest_alloc(uint32_t size) {
  uint32_t sz = (size + 15) & ~15u; if (!sz) sz = 16;
  if ((uint64_t)live_bytes_ + sz > (uint64_t)ram_limit_mb * 1024ull * 1024ull) { ram_limit_hit = true; return 0; }
  live_bytes_ += sz;
  auto it = free_lists_.find(sz);
  if (it != free_lists_.end() && !it->second.empty()) { uint32_t p = it->second.back(); it->second.pop_back(); return p; }
  uint32_t p = heap_ptr_ + 8;
  heap_ptr_ += sz + 16;
  mem.write32(p - 8, sz);
  return p;
}
void Core::guest_free(uint32_t p) { if (!p) return; uint32_t sz = mem.read32(p - 8); if (live_bytes_ >= sz) live_bytes_ -= sz; free_lists_[sz].push_back(p); }
uint32_t Core::alloc_cstr(const std::string& s) {
  uint32_t p = guest_alloc((uint32_t)s.size() + 1);
  mem.write_bytes(p, s.c_str(), s.size() + 1); return p;
}
void Core::out(const std::string& s) {
  log += "  [game] " + s; if (s.empty() || s.back() != '\n') log += "\n";
}

uint32_t Core::trap_addr(const std::string& name) {
  auto it = trap_ids_.find(name);
  if (it != trap_ids_.end()) return TRAP_BASE + it->second * 4;
  uint32_t id = (uint32_t)trap_names_.size();
  trap_names_.push_back(name); trap_ids_[name] = id;
  return TRAP_BASE + id * 4;
}

uint32_t Core::data_symbol(const std::string& name, bool& is_data) {
  is_data = true;
  auto it = data_syms_.find(name);
  if (it != data_syms_.end()) return it->second;
  auto alloc = [&](uint32_t size) { uint32_t a = data_ptr_; data_ptr_ += (size + 15) & ~15u; mem.map(a, size); return a; };
  uint32_t a = 0;
  if (name == "___stack_chk_guard") { a = alloc(4); mem.write32(a, 0xA5C3E1F0u); }
  else if (name == "___stderrp" || name == "___stdoutp" || name == "___stdinp") {
    uint32_t file = alloc(88); mem.write32(file + 0x40, name == "___stdinp" ? 0 : (name == "___stdoutp" ? 1 : 2));
    a = alloc(4); mem.write32(a, file);
  }
  else if (name == "__DefaultRuneLocale") {
    a = alloc(3200);
    for (int ch = 0; ch < 256; ch++) {
      uint32_t f = 0;
      bool up = ch >= 'A' && ch <= 'Z', lo = ch >= 'a' && ch <= 'z', dg = ch >= '0' && ch <= '9';
      bool sp = ch == ' ' || (ch >= 9 && ch <= 13), xd = dg || (ch >= 'a' && ch <= 'f') || (ch >= 'A' && ch <= 'F');
      bool pr = ch >= 32 && ch < 127, cn = ch < 32 || ch == 127, gr = ch > 32 && ch < 127;
      bool pu = gr && !up && !lo && !dg;
      if (up || lo) f |= 0x100; if (cn) f |= 0x200; if (dg) f |= 0x400; if (gr) f |= 0x800; if (lo) f |= 0x1000;
      if (pu) f |= 0x2000; if (sp) f |= 0x4000; if (up) f |= 0x8000; if (xd) f |= 0x10000; if (ch == ' ' || ch == '\t') f |= 0x20000; if (pr) f |= 0x40000;
      if (dg) f |= (ch - '0'); else if (xd) f |= (10 + ((ch | 0x20) - 'a'));
      mem.write32(a + 52 + ch * 4, f);
      mem.write32(a + 1076 + ch * 4, up ? ch + 32 : ch);
      mem.write32(a + 2100 + ch * 4, lo ? ch - 32 : ch);
    }
  }
  else if (name == "_environ") { uint32_t arr = alloc(8); a = alloc(4); mem.write32(a, arr); }
  else if (name == "___progname") { a = alloc(4); mem.write32(a, alloc_cstr(app_name)); }
  else if (name == "_NXArgc") { a = alloc(4); mem.write32(a, 1); }
  else if (name == "_NXArgv") { a = alloc(4); mem.write32(a, argv_ptr_); }
  else if (name == "_mach_task_self_") { a = alloc(4); mem.write32(a, 0x103); }
  else if (name == "_vm_page_size") { a = alloc(4); mem.write32(a, 4096); }
  else if (name == "_vm_page_mask") { a = alloc(4); mem.write32(a, 4095); }
  else if (name == "_vm_page_shift") { a = alloc(4); mem.write32(a, 12); }
  else is_data = false;
  if (is_data) data_syms_[name] = a;
  return a;
}

uint32_t Core::symbol_addr(const std::string& name) {
  bool is_data; uint32_t a = data_symbol(name, is_data);
  return is_data ? a : trap_addr(name);
}

bool Core::load_file(const std::string& path) {
  std::ifstream in(path, std::ios::binary);
  if (!in) { log += "Cannot open " + path + "\n"; return false; }
  std::vector<uint8_t> f((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
  if (!parse_macho(f, info)) { log += "Mach-O error: " + info.error + "\n"; return false; }
  if (info.cputype != 12) { log += "Unsupported CPU type\n"; return false; }
  if (info.has_crypt && info.cryptid) { log += "This binary is still encrypted (FairPlay). A decrypted IPA is needed.\n"; return false; }
  size_t base = info.slice_off;
  for (auto& s : info.segs) {
    if (s.name == "__PAGEZERO" || s.vmsize == 0) continue;
    mem.map(s.vmaddr, s.vmsize);
    if (s.filesize && base + s.fileoff + s.filesize <= f.size()) mem.write_bytes(s.vmaddr, f.data() + base + s.fileoff, s.filesize);
  }
  mem.map(0xFFFF4000u, 0x1000);   // commpage
  setup_stack();
  bind_all();
  return true;
}

void Core::setup_stack() {
  uint32_t top = sp_top_ - 0x100;
  std::string path = "/var/mobile/Applications/AstralHLE/" + app_name + ".app/" + app_name;
  uint32_t pstr = top - 0x200; mem.write_bytes(pstr, path.c_str(), path.size() + 1);
  uint32_t sp = (top - 0x400) & ~7u;
  mem.write32(sp, 1);           // argc
  mem.write32(sp + 4, pstr);    // argv[0]
  mem.write32(sp + 8, 0);       // argv terminator
  mem.write32(sp + 12, 0);      // envp terminator
  mem.write32(sp + 16, pstr);   // apple[0]
  mem.write32(sp + 20, 0);
  argv_ptr_ = sp + 4; envp_ptr_ = sp + 12; apple_ptr_ = sp + 16;
  cpu.r[13] = sp;
}

void Core::bind_all() {
  size_t nbound = 0;
  for (auto& s : info.secs) {
    if (s.type() != 6 && s.type() != 7) continue;   // non-lazy / lazy symbol pointers
    uint32_t count = s.size / 4;
    for (uint32_t i = 0; i < count; i++) {
      uint32_t idx = s.reserved1 + i;
      if (idx >= info.indirect.size()) continue;
      uint32_t sym = info.indirect[idx];
      if (sym & 0x80000000u) continue;   // local / absolute
      if (sym >= info.syms.size()) continue;
      mem.write32(s.addr + i * 4, symbol_addr(info.syms[sym].name)); nbound++;
    }
  }
  for (auto& r : info.extrels) {
    if (!r.ext || r.length != 2 || r.symnum >= info.syms.size()) continue;
    uint32_t addr = (info.segs.empty() ? 0 : info.segs[0].vmaddr) + r.addr;
    mem.write32(addr, symbol_addr(info.syms[r.symnum].name) + mem.read32(addr)); nbound++;
  }
  log += "Bound " + std::to_string(nbound) + " imports (" + std::to_string(trap_names_.size() - 1) + " functions).\n";
}

uint32_t Core::call_guest(uint32_t addr, std::initializer_list<uint32_t> args) {
  Cpu saved = cpu;
  int i = 0; for (uint32_t a : args) { if (i < 4) cpu.r[i] = a; i++; }
  cpu.r[14] = RET_SENTINEL; cpu.thumb = addr & 1; cpu.r[15] = addr & ~1u;
  Stop s = pump(cpu.icount + 200000000ull);
  uint32_t result = cpu.r[0];
  uint64_t ic = cpu.icount;
  if (s == Stop::Returned) { cpu = saved; cpu.icount = ic; cpu.r[0] = result; }
  return result;
}

bool Core::dispatch_trap() {
  uint32_t id = cpu.trap_index;
  if (id == 0 || id >= trap_names_.size()) { stop_reason = "jump to invalid trap address " + hex(cpu.r[15]); return false; }
  const std::string& name = trap_names_[id];
  auto it = fns.find(name);
  hle_calls++;
  recent_calls.push_back(name); if (recent_calls.size() > 24) recent_calls.erase(recent_calls.begin());
  if (it == fns.end()) {
    stop_reason = "reached an import that is not implemented yet: " + name + " (called from " + hex(cpu.r[14] & ~1u) + ")";
    if (name == "_objc_msgSend" || name == "_objc_msgSend_stret" || name == "_objc_msgSendSuper") {
      std::string sel = mem.cstring(cpu.r[1], 80);
      std::string who = "an object";
      uint32_t r0 = cpu.r[0];
      if (r0 >= TRAP_BASE && r0 < TRAP_END && ((r0 - TRAP_BASE) >> 2) < trap_names_.size()) who = trap_names_[(r0 - TRAP_BASE) >> 2];
      stop_reason += "\n  Objective-C message '" + sel + "' sent to " + who;
    }
    return false;
  }
  it->second(*this);
  if (exited) return false;
  cpu.return_from_trap();
  return true;
}

Stop Core::pump(uint64_t limit) {
  while (true) {
    if (cpu.icount >= limit) return Stop::Limit;
    Stop s = cpu.run(limit - cpu.icount);
    if (s == Stop::Trap) { if (!dispatch_trap()) return Stop::Trap; continue; }
    return s;
  }
}

static std::string stop_text(Core& c, Stop s) {
  std::ostringstream o;
  switch (s) {
    case Stop::Limit: o << "stopped: instruction limit reached"; break;
    case Stop::Undefined: o << "stopped: unsupported instruction " << hex(c.cpu.last_insn) << " at " << hex(c.cpu.r[15] - (c.cpu.thumb ? 2 : 4)) << " (" << c.cpu.undef_note << ")"; break;
    case Stop::Fault: o << "stopped: memory access fault at " << hex(c.mem.fault_addr) << (c.mem.fault_write ? " (write)" : " (read)") << ", pc=" << hex(c.cpu.r[15]); break;
    case Stop::Swi: o << "stopped: system call (SWI #" << c.cpu.swi_num << ") at " << hex(c.cpu.r[15]) << ", r12=" << (int32_t)c.cpu.r[12]; break;
    case Stop::Returned: o << "returned normally"; break;
    default: o << "stopped"; break;
  }
  return o.str();
}

std::string Core::run_report(const std::string& path, uint64_t max_insns) {
  log.clear(); stop_reason.clear();
  log += "AstralHLE core 0.2.0\n";
  if (!load_file(path)) return log;
  {
    char b[200];
    snprintf(b, sizeof b, "Binary: %s%s, minimum iOS %u.%u, %s\n", info.arch_name().c_str(), info.fat ? " (fat)" : "", info.minos >> 16, (info.minos >> 8) & 255,
             info.has_crypt ? "decrypted" : "no encryption info");
    log += b;
    if (!info.minos) { size_t k = log.rfind(", minimum iOS 0.0"); if (k != std::string::npos) log.replace(k, 17, ", minimum iOS not specified"); }
    log += "Libraries: " + std::to_string(info.dylibs.size()) + ", entry point " + hex(info.entry_pc) + (info.entry_thumb ? " (Thumb)" : " (ARM)") + "\n";
    if ((info.cpusubtype & 0xff) >= 9) log += "Note: ARMv7 code can use Thumb-2/NEON, which this core does not support yet.\n";
    if (info.has_dyld_info) log += "Note: compressed dyld info found (not supported yet, imports may be unbound).\n";
  }
  // static initializers, then the program entry point (as dyld would do)
  Stop s = Stop::Returned;
  uint32_t argc = 1;
  for (auto& sec : info.secs) {
    if (sec.type() != 9) continue;
    for (uint32_t i = 0; i < sec.size / 4 && s == Stop::Returned && !exited; i++) {
      uint32_t fn = mem.read32(sec.addr + i * 4);
      if (!fn) continue;
      cpu.icount += 0;
      s = Stop::Returned;
      uint32_t sp0 = cpu.r[13];
      Cpu saved = cpu;
      cpu.r[0] = argc; cpu.r[1] = argv_ptr_; cpu.r[2] = envp_ptr_; cpu.r[3] = apple_ptr_;
      cpu.r[14] = RET_SENTINEL; cpu.thumb = fn & 1; cpu.r[15] = fn & ~1u;
      s = pump(max_insns);
      if (s == Stop::Returned) { uint64_t ic = cpu.icount; cpu = saved; cpu.icount = ic; cpu.r[13] = sp0; }
      else break;
    }
  }
  if (s == Stop::Returned && !exited) {
    cpu.r[15] = info.entry_pc & ~1u; cpu.thumb = info.entry_thumb; cpu.r[14] = RET_SENTINEL;
    s = pump(max_insns);
  }
  log += "\nRAM limit: " + std::to_string(ram_limit_mb) + " MB, game heap in use: " + std::to_string(live_bytes_ / 1024) + " KB" + (ram_limit_hit ? " (limit reached, malloc returned NULL)" : "") + "\n";
  log += "\nRun result: ";
  if (exited) log += "program called exit(" + std::to_string(exit_code) + ")" + (stop_reason.empty() ? "" : " - " + stop_reason);
  else if (!stop_reason.empty() && s == Stop::Trap) log += stop_reason;
  else log += stop_text(*this, s);
  log += "\nInstructions executed: " + std::to_string(cpu.icount) + ", HLE calls: " + std::to_string(hle_calls) + "\n";
  if (!recent_calls.empty()) {
    log += "Last calls: ";
    size_t from = recent_calls.size() > 10 ? recent_calls.size() - 10 : 0;
    for (size_t i = from; i < recent_calls.size(); i++) log += recent_calls[i] + (i + 1 < recent_calls.size() ? ", " : "");
    log += "\n";
  }
  return log;
}

}  // namespace astral
