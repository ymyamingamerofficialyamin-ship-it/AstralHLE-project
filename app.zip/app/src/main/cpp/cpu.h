// AstralHLE core: ARMv6 (ARM + Thumb-1) interpreter.
#pragma once
#include "mem.h"

namespace astral {

constexpr uint32_t TRAP_BASE = 0xE0000000u;     // calls into HLE functions land here
constexpr uint32_t TRAP_END = 0xE0100000u;
constexpr uint32_t RET_SENTINEL = 0xE00FFFF0u;  // "return to host"

enum class Stop { Running, Limit, Trap, Undefined, Fault, Swi, Returned };

struct Cpu {
  uint32_t r[16] = {0};
  bool N = false, Z = false, C = false, V = false, thumb = false;
  uint32_t tls = 0;
  uint32_t s[64] = {0};     // VFP single registers (doubles overlay pairs)
  uint32_t fpscr = 0;
  uint64_t icount = 0;
  Memory* mem = nullptr;
  uint32_t last_insn = 0;
  uint32_t trap_index = 0;
  uint32_t swi_num = 0;
  uint32_t ring[32] = {0};
  unsigned ringpos = 0;
  const char* undef_note = "";

  Stop run(uint64_t max);
  void return_from_trap() { uint32_t lr = r[14]; thumb = lr & 1; r[15] = lr & ~1u; }

 private:
  Stop step_arm();
  Stop step_thumb();
  Stop step_vfp(uint32_t insn, uint32_t pc);
  bool cond_pass(uint32_t c) const;
  void set_nz(uint32_t v) { N = v >> 31; Z = (v == 0); }
};

}  // namespace astral
