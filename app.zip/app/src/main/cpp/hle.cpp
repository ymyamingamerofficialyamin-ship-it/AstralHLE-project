// AstralHLE core: high-level emulation of libSystem (C library, pthread, mach, dyld).
#include "core.h"
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdlib>

namespace astral {

namespace {

struct ArgSrc {
  Core& c; int slot; uint32_t va; bool isva;
  uint32_t next32() {
    if (isva) { uint32_t v = c.mem.read32(va); va += 4; return v; }
    uint32_t v = slot < 4 ? c.cpu.r[slot] : c.mem.read32(c.cpu.r[13] + 4 * (slot - 4)); slot++; return v;
  }
  uint64_t next64() {
    if (isva) { va = (va + 7) & ~7u; uint64_t lo = c.mem.read32(va), hi = c.mem.read32(va + 4); va += 8; return lo | (hi << 32); }
    if (slot & 1) slot++;
    uint64_t lo = next32(); uint64_t hi = next32(); return lo | (hi << 32);
  }
};

double bits_to_double(uint32_t lo, uint32_t hi) { uint64_t b = ((uint64_t)hi << 32) | lo; double d; memcpy(&d, &b, 8); return d; }
void ret_double(Core& c, double d) { uint64_t b; memcpy(&b, &d, 8); c.ret64(b); }
float bits_to_float(uint32_t v) { float f; memcpy(&f, &v, 4); return f; }
void ret_float(Core& c, float f) { uint32_t b; memcpy(&b, &f, 4); c.ret(b); }

uint64_t now_ns() { return (uint64_t)std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count(); }

}  // namespace

std::string Core::format_c(uint32_t fmt, int first_slot, uint32_t va_ptr, bool use_va) {
  ArgSrc a{*this, first_slot, va_ptr, use_va};
  std::string f = mem.cstring(fmt, 4096), out;
  for (size_t i = 0; i < f.size(); i++) {
    if (f[i] != '%') { out.push_back(f[i]); continue; }
    i++; if (i >= f.size()) break;
    if (f[i] == '%') { out.push_back('%'); continue; }
    std::string flags; int width = -1, prec = -1;
    while (i < f.size() && strchr("-+ #0", f[i])) flags.push_back(f[i++]);
    if (i < f.size() && f[i] == '*') { width = (int)a.next32(); i++; if (width < 0) { flags += "-"; width = -width; } }
    else { if (i < f.size() && isdigit((unsigned char)f[i])) { width = 0; while (i < f.size() && isdigit((unsigned char)f[i])) width = width * 10 + (f[i++] - '0'); } }
    if (i < f.size() && f[i] == '.') {
      i++; prec = 0;
      if (i < f.size() && f[i] == '*') { prec = (int)a.next32(); i++; }
      else while (i < f.size() && isdigit((unsigned char)f[i])) prec = prec * 10 + (f[i++] - '0');
    }
    int lng = 0;
    while (i < f.size() && strchr("hlzjtLq", f[i])) { if (f[i] == 'l' || f[i] == 'q' || f[i] == 'j') lng++; i++; }
    if (i >= f.size()) break;
    char conv = f[i];
    std::string spec = "%" + flags;
    if (width >= 0) spec += std::to_string(width);
    if (prec >= 0) spec += "." + std::to_string(prec);
    char buf[512];
    switch (conv) {
      case 'd': case 'i': {
        long long v = lng >= 2 ? (long long)a.next64() : (long long)(int32_t)a.next32();
        snprintf(buf, sizeof buf, (spec + "lld").c_str(), v); out += buf; break; }
      case 'u': case 'x': case 'X': case 'o': {
        unsigned long long v = lng >= 2 ? a.next64() : (unsigned long long)a.next32();
        snprintf(buf, sizeof buf, (spec + "ll" + conv).c_str(), v); out += buf; break; }
      case 'c': { snprintf(buf, sizeof buf, (spec + "c").c_str(), (int)a.next32()); out += buf; break; }
      case 'p': { snprintf(buf, sizeof buf, "0x%x", a.next32()); out += buf; break; }
      case 's': { uint32_t p = a.next32(); std::string s = p ? mem.cstring(p, 8192) : "(null)"; snprintf(buf, sizeof buf, (spec + "s").c_str(), s.c_str()); out += buf; break; }
      case 'f': case 'F': case 'e': case 'E': case 'g': case 'G': case 'a': case 'A': {
        double d = bits_to_double((uint32_t)0, 0); uint64_t b = a.next64(); memcpy(&d, &b, 8);
        snprintf(buf, sizeof buf, (spec + conv).c_str(), d); out += buf; break; }
      case 'n': a.next32(); break;
      default: out.push_back('%'); out.push_back(conv);
    }
  }
  return out;
}

void install_hle(Core& core) {
  auto& F = core.fns;
  auto rd = [](Core& c, uint32_t a) { return c.mem.read8(a); };

  // ---------------------------------------------------------------- startup / mach / dyld
  for (const char* n : {"_mach_init_routine", "__cthread_init_routine", "___keymgr_dwarf2_register_sections", "__dyld_register_func_for_add_image",
                        "__dyld_register_func_for_remove_image", "_pthread_mutexattr_init", "_pthread_mutexattr_settype", "_pthread_mutexattr_destroy",
                        "_pthread_attr_init", "_pthread_attr_destroy", "_pthread_attr_setdetachstate", "_pthread_attr_setstacksize", "_signal", "_sigaction", "_setlocale_dummy"})
    F[n] = [](Core& c) { c.ret(0); };
  F["_atexit"] = [](Core& c) { c.ret(0); };
  F["___cxa_atexit"] = [](Core& c) { c.ret(0); };
  F["___cxa_finalize"] = [](Core& c) { c.ret(0); };
  F["_mach_absolute_time"] = [](Core& c) { c.ret64(now_ns()); };
  F["_mach_timebase_info"] = [](Core& c) { uint32_t p = c.arg(0); c.mem.write32(p, 1); c.mem.write32(p + 4, 1); c.ret(0); };
  F["_mach_task_self"] = [](Core& c) { c.ret(0x103); };
  F["__dyld_image_count"] = [](Core& c) { c.ret(1); };
  F["__dyld_get_image_vmaddr_slide"] = [](Core& c) { c.ret(0); };
  F["__dyld_get_image_header"] = [](Core& c) { uint32_t a = 0; for (auto& s : c.info.segs) if (s.name == "__TEXT") a = s.vmaddr; c.ret(a); };
  F["__NSGetArgc"] = [](Core& c) { uint32_t p = c.guest_alloc(4); c.mem.write32(p, 1); c.ret(p); };
  F["__NSGetArgv"] = [](Core& c) { uint32_t p = c.guest_alloc(4); c.mem.write32(p, c.argv_ptr_); c.ret(p); };
  F["__NSGetExecutablePath"] = [](Core& c) {
    std::string path = "/var/mobile/Applications/AstralHLE/" + c.app_name + ".app/" + c.app_name;
    uint32_t buf = c.arg(0), szp = c.arg(1);
    if (c.mem.read32(szp) < path.size() + 1) { c.mem.write32(szp, (uint32_t)path.size() + 1); c.ret(0xFFFFFFFFu); return; }
    c.mem.write_bytes(buf, path.c_str(), path.size() + 1); c.ret(0); };

  // ---------------------------------------------------------------- memory
  F["_malloc"] = [](Core& c) { c.ret(c.guest_alloc(c.arg(0))); };
  F["_valloc"] = F["_malloc"];
  F["_calloc"] = [](Core& c) { uint32_t n = c.arg(0) * c.arg(1); uint32_t p = c.guest_alloc(n); c.mem.fill(p, 0, n); c.ret(p); };
  F["_free"] = [](Core& c) { c.guest_free(c.arg(0)); };
  F["_realloc"] = [](Core& c) {
    uint32_t old = c.arg(0), n = c.arg(1);
    if (!old) { c.ret(c.guest_alloc(n)); return; }
    uint32_t osz = c.guest_size(old);
    if (n <= osz) { c.ret(old); return; }
    uint32_t p = c.guest_alloc(n); std::vector<uint8_t> t(osz); c.mem.read_bytes(old, t.data(), osz); c.mem.write_bytes(p, t.data(), osz);
    c.guest_free(old); c.ret(p); };
  F["_memcpy"] = [](Core& c) {
    uint32_t d = c.arg(0), s = c.arg(1), n = c.arg(2); std::vector<uint8_t> t(n); c.mem.read_bytes(s, t.data(), n); c.mem.write_bytes(d, t.data(), n); c.ret(d); };
  F["_memmove"] = F["_memcpy"]; F["___memcpy_chk"] = F["_memcpy"]; F["___memmove_chk"] = F["_memcpy"];
  F["_memset"] = [](Core& c) { c.mem.fill(c.arg(0), (uint8_t)c.arg(1), c.arg(2)); c.ret(c.arg(0)); };
  F["___memset_chk"] = F["_memset"];
  F["_bzero"] = [](Core& c) { c.mem.fill(c.arg(0), 0, c.arg(1)); };
  F["_memcmp"] = [](Core& c) {
    uint32_t a = c.arg(0), b = c.arg(1), n = c.arg(2); int r = 0;
    for (uint32_t i = 0; i < n && !r; i++) r = (int)c.mem.read8(a + i) - (int)c.mem.read8(b + i);
    c.ret((uint32_t)r); };
  F["_memchr"] = [](Core& c) {
    uint32_t p = c.arg(0), n = c.arg(2); uint8_t v = (uint8_t)c.arg(1);
    for (uint32_t i = 0; i < n; i++) if (c.mem.read8(p + i) == v) { c.ret(p + i); return; }
    c.ret(0); };

  // ---------------------------------------------------------------- strings
  F["_strlen"] = [](Core& c) { uint32_t p = c.arg(0), n = 0; while (c.mem.read8(p + n) && !c.mem.fault) n++; c.ret(n); };
  F["_strcmp"] = [](Core& c) {
    uint32_t a = c.arg(0), b = c.arg(1); int r = 0;
    for (uint32_t i = 0;; i++) { uint8_t x = c.mem.read8(a + i), y = c.mem.read8(b + i); if (x != y) { r = (int)x - (int)y; break; } if (!x) break; }
    c.ret((uint32_t)r); };
  F["_strncmp"] = [](Core& c) {
    uint32_t a = c.arg(0), b = c.arg(1), n = c.arg(2); int r = 0;
    for (uint32_t i = 0; i < n; i++) { uint8_t x = c.mem.read8(a + i), y = c.mem.read8(b + i); if (x != y) { r = (int)x - (int)y; break; } if (!x) break; }
    c.ret((uint32_t)r); };
  F["_strcasecmp"] = [](Core& c) {
    uint32_t a = c.arg(0), b = c.arg(1); int r = 0;
    for (uint32_t i = 0;; i++) { int x = tolower(c.mem.read8(a + i)), y = tolower(c.mem.read8(b + i)); if (x != y) { r = x - y; break; } if (!x) break; }
    c.ret((uint32_t)r); };
  F["_strncasecmp"] = [](Core& c) {
    uint32_t a = c.arg(0), b = c.arg(1), n = c.arg(2); int r = 0;
    for (uint32_t i = 0; i < n; i++) { int x = tolower(c.mem.read8(a + i)), y = tolower(c.mem.read8(b + i)); if (x != y) { r = x - y; break; } if (!x) break; }
    c.ret((uint32_t)r); };
  F["_strcpy"] = [](Core& c) { uint32_t d = c.arg(0), s = c.arg(1); uint32_t i = 0; for (;; i++) { uint8_t v = c.mem.read8(s + i); c.mem.write8(d + i, v); if (!v) break; } c.ret(d); };
  F["___strcpy_chk"] = F["_strcpy"];
  F["_strncpy"] = [](Core& c) {
    uint32_t d = c.arg(0), s = c.arg(1), n = c.arg(2); bool end = false;
    for (uint32_t i = 0; i < n; i++) { uint8_t v = end ? 0 : c.mem.read8(s + i); if (!v) end = true; c.mem.write8(d + i, v); }
    c.ret(d); };
  F["___strncpy_chk"] = F["_strncpy"];
  F["_strcat"] = [](Core& c) {
    uint32_t d = c.arg(0), s = c.arg(1), n = 0; while (c.mem.read8(d + n)) n++;
    for (uint32_t i = 0;; i++) { uint8_t v = c.mem.read8(s + i); c.mem.write8(d + n + i, v); if (!v) break; }
    c.ret(d); };
  F["___strcat_chk"] = F["_strcat"];
  F["_strncat"] = [](Core& c) {
    uint32_t d = c.arg(0), s = c.arg(1), m = c.arg(2), n = 0; while (c.mem.read8(d + n)) n++;
    uint32_t i = 0; for (; i < m; i++) { uint8_t v = c.mem.read8(s + i); if (!v) break; c.mem.write8(d + n + i, v); }
    c.mem.write8(d + n + i, 0); c.ret(d); };
  F["_strchr"] = [](Core& c) {
    uint32_t p = c.arg(0); uint8_t ch = (uint8_t)c.arg(1);
    for (uint32_t i = 0;; i++) { uint8_t v = c.mem.read8(p + i); if (v == ch) { c.ret(p + i); return; } if (!v) break; }
    c.ret(0); };
  F["_strrchr"] = [](Core& c) {
    uint32_t p = c.arg(0); uint8_t ch = (uint8_t)c.arg(1); uint32_t last = 0;
    for (uint32_t i = 0;; i++) { uint8_t v = c.mem.read8(p + i); if (v == ch) last = p + i; if (!v) break; }
    c.ret(last); };
  F["_strstr"] = [](Core& c) {
    std::string h = c.mem.cstring(c.arg(0), 1 << 20), n = c.mem.cstring(c.arg(1), 4096); size_t pos = h.find(n);
    c.ret(pos == std::string::npos ? 0 : c.arg(0) + (uint32_t)pos); };
  F["_strdup"] = [](Core& c) { c.ret(c.alloc_cstr(c.mem.cstring(c.arg(0), 1 << 20))); };
  F["_atoi"] = [](Core& c) { c.ret((uint32_t)atoi(c.mem.cstring(c.arg(0), 64).c_str())); };
  F["_atol"] = F["_atoi"];
  F["_strtol"] = [](Core& c) {
    std::string s = c.mem.cstring(c.arg(0), 128); char* end = nullptr; long v = strtol(s.c_str(), &end, (int)c.arg(2));
    if (c.arg(1)) c.mem.write32(c.arg(1), c.arg(0) + (uint32_t)(end - s.c_str())); c.ret((uint32_t)v); };
  F["_strtoul"] = F["_strtol"];
  F["_toupper"] = [](Core& c) { c.ret((uint32_t)toupper((int)c.arg(0))); };
  F["_tolower"] = [](Core& c) { c.ret((uint32_t)tolower((int)c.arg(0))); };
  F["___maskrune"] = [](Core& c) {   // used by isalpha() etc.: look the character class up in our rune table
    uint32_t ch = c.arg(0) & 0xFF, mask = c.arg(1); uint32_t table = 0;
    bool is_data; table = c.data_symbol("__DefaultRuneLocale", is_data);
    c.ret(c.mem.read32(table + 52 + ch * 4) & mask); };

  // ---------------------------------------------------------------- stdio (output only for now)
  F["_printf"] = [](Core& c) { c.out(c.format_c(c.arg(0), 1, 0, false)); c.ret(0); };
  F["_puts"] = [](Core& c) { c.out(c.mem.cstring(c.arg(0))); c.ret(0); };
  F["_putchar"] = [](Core& c) { c.ret(c.arg(0)); };
  F["_fprintf"] = [](Core& c) { c.out(c.format_c(c.arg(1), 2, 0, false)); c.ret(0); };
  F["_vprintf"] = [](Core& c) { c.out(c.format_c(c.arg(0), 0, c.arg(1), true)); c.ret(0); };
  F["_vfprintf"] = [](Core& c) { c.out(c.format_c(c.arg(1), 0, c.arg(2), true)); c.ret(0); };
  F["_fputs"] = [](Core& c) { c.out(c.mem.cstring(c.arg(0))); c.ret(0); };
  F["_fflush"] = [](Core& c) { c.ret(0); };
  F["_sprintf"] = [](Core& c) { std::string s = c.format_c(c.arg(1), 2, 0, false); c.mem.write_bytes(c.arg(0), s.c_str(), s.size() + 1); c.ret((uint32_t)s.size()); };
  F["___sprintf_chk"] = [](Core& c) { std::string s = c.format_c(c.arg(3), 4, 0, false); c.mem.write_bytes(c.arg(0), s.c_str(), s.size() + 1); c.ret((uint32_t)s.size()); };
  F["_snprintf"] = [](Core& c) {
    std::string s = c.format_c(c.arg(2), 3, 0, false); uint32_t n = c.arg(1);
    if (n) { std::string t = s.substr(0, n - 1); c.mem.write_bytes(c.arg(0), t.c_str(), t.size() + 1); }
    c.ret((uint32_t)s.size()); };
  F["___snprintf_chk"] = [](Core& c) {
    std::string s = c.format_c(c.arg(4), 5, 0, false); uint32_t n = c.arg(1);
    if (n) { std::string t = s.substr(0, n - 1); c.mem.write_bytes(c.arg(0), t.c_str(), t.size() + 1); }
    c.ret((uint32_t)s.size()); };
  F["_vsnprintf"] = [](Core& c) {
    std::string s = c.format_c(c.arg(2), 0, c.arg(3), true); uint32_t n = c.arg(1);
    if (n) { std::string t = s.substr(0, n - 1); c.mem.write_bytes(c.arg(0), t.c_str(), t.size() + 1); }
    c.ret((uint32_t)s.size()); };
  F["_vsprintf"] = [](Core& c) { std::string s = c.format_c(c.arg(1), 0, c.arg(2), true); c.mem.write_bytes(c.arg(0), s.c_str(), s.size() + 1); c.ret((uint32_t)s.size()); };

  // ---------------------------------------------------------------- process / stdlib
  F["_abort"] = [](Core& c) { c.request_exit(134, "abort() was called"); };
  F["_exit"] = [](Core& c) { c.request_exit((int)c.arg(0), "exit() was called"); };
  F["__exit"] = F["_exit"];
  F["___stack_chk_fail"] = [](Core& c) { c.request_exit(134, "stack protector check failed"); };
  F["___cxa_pure_virtual"] = [](Core& c) { c.request_exit(134, "pure virtual function called"); };
  F["___cxa_guard_acquire"] = [](Core& c) { c.ret(c.mem.read8(c.arg(0)) == 0 ? 1 : 0); };
  F["___cxa_guard_release"] = [](Core& c) { c.mem.write8(c.arg(0), 1); };
  F["___cxa_guard_abort"] = [](Core& c) { (void)c; };
  F["_getenv"] = [](Core& c) { c.ret(0); };
  F["_setenv"] = [](Core& c) { c.ret(0); };
  F["_abs"] = [](Core& c) { int v = (int)c.arg(0); c.ret((uint32_t)(v < 0 ? -v : v)); };
  F["___error"] = [](Core& c) { static uint32_t cell = 0; if (!cell) cell = c.guest_alloc(4); c.ret(cell); };
  F["_strerror"] = [](Core& c) { static uint32_t s = 0; if (!s) s = c.alloc_cstr("error"); c.ret(s); };
  F["_sysconf"] = [](Core& c) { uint32_t n = c.arg(0); c.ret(n == 29 ? 4096 : (n == 57 || n == 58) ? 1 : 0xFFFFFFFFu); };
  F["_sysctlbyname"] = [](Core& c) {
    std::string name = c.mem.cstring(c.arg(0)); uint32_t oldp = c.arg(1), lenp = c.arg(2);
    std::string val;
    if (name == "hw.machine") val = c.device_model; else if (name == "hw.model") val = "N82AP"; else if (name == "kern.osversion") val = "7E18";
    else if (name == "hw.ncpu" || name == "hw.activecpu") { if (oldp) c.mem.write32(oldp, 1); if (lenp) c.mem.write32(lenp, 4); c.ret(0); return; }
    else if (name == "hw.physmem" || name == "hw.memsize") { if (oldp) c.mem.write32(oldp, 128u << 20); if (lenp) c.mem.write32(lenp, 4); c.ret(0); return; }
    else { c.ret(0xFFFFFFFFu); return; }
    if (oldp) c.mem.write_bytes(oldp, val.c_str(), val.size() + 1);
    if (lenp) c.mem.write32(lenp, (uint32_t)val.size() + 1);
    c.ret(0); };
  static uint32_t rng = 1;
  F["_srand"] = [](Core& c) { rng = c.arg(0); }; F["_srandom"] = F["_srand"];
  F["_rand"] = [](Core& c) { rng = rng * 1103515245u + 12345u; c.ret((rng >> 8) & 0x7FFFFFFF); }; F["_random"] = F["_rand"];

  // ---------------------------------------------------------------- time
  F["_time"] = [](Core& c) { uint32_t t = (uint32_t)(now_ns() / 1000000000ull) + 1230768000u; if (c.arg(0)) c.mem.write32(c.arg(0), t); c.ret(t); };
  F["_gettimeofday"] = [](Core& c) {
    uint64_t ns = now_ns(); uint32_t p = c.arg(0);
    if (p) { c.mem.write32(p, (uint32_t)(ns / 1000000000ull) + 1230768000u); c.mem.write32(p + 4, (uint32_t)((ns / 1000) % 1000000)); }
    c.ret(0); };
  for (const char* n : {"_usleep", "_sleep", "_nanosleep", "_sched_yield"}) F[n] = [](Core& c) { c.ret(0); };

  // ---------------------------------------------------------------- pthread (single threaded for now)
  for (const char* n : {"_pthread_mutex_init", "_pthread_mutex_lock", "_pthread_mutex_unlock", "_pthread_mutex_destroy", "_pthread_mutex_trylock",
                        "_pthread_cond_init", "_pthread_cond_destroy", "_pthread_cond_signal", "_pthread_cond_broadcast"})
    F[n] = [](Core& c) { c.ret(0); };
  F["_pthread_self"] = [](Core& c) { c.ret(0x1000); };
  static uint32_t next_key = 1; static std::unordered_map<uint32_t, uint32_t> tls_values;
  F["_pthread_key_create"] = [](Core& c) { c.mem.write32(c.arg(0), next_key++); c.ret(0); };
  F["_pthread_getspecific"] = [](Core& c) { auto it = tls_values.find(c.arg(0)); c.ret(it == tls_values.end() ? 0 : it->second); };
  F["_pthread_setspecific"] = [](Core& c) { tls_values[c.arg(0)] = c.arg(1); c.ret(0); };
  F["_pthread_once"] = [](Core& c) {
    uint32_t ctl = c.arg(0), fn = c.arg(1);
    if (c.mem.read32(ctl) != 0x30B1BCC5u) { c.mem.write32(ctl, 0x30B1BCC5u); c.call_guest(fn, {}); }
    c.ret(0); };

  // ---------------------------------------------------------------- math (soft-float ABI: floats in r0, doubles in r0:r1)
#define MATH_F1(name, expr) F["_" name "f"] = [](Core& c) { float x = bits_to_float(c.arg(0)); ret_float(c, (float)(expr)); }; \
  F["_" name] = [](Core& c) { double x = bits_to_double(c.arg(0), c.arg(1)); ret_double(c, (expr)); };
  MATH_F1("sin", std::sin(x)) MATH_F1("cos", std::cos(x)) MATH_F1("tan", std::tan(x)) MATH_F1("sqrt", std::sqrt(x)) MATH_F1("floor", std::floor(x))
  MATH_F1("ceil", std::ceil(x)) MATH_F1("fabs", std::fabs(x)) MATH_F1("exp", std::exp(x)) MATH_F1("log", std::log(x)) MATH_F1("atan", std::atan(x))
  MATH_F1("asin", std::asin(x)) MATH_F1("acos", std::acos(x)) MATH_F1("log10", std::log10(x))
  F["_powf"] = [](Core& c) { ret_float(c, std::pow(bits_to_float(c.arg(0)), bits_to_float(c.arg(1)))); };
  F["_pow"] = [](Core& c) { ret_double(c, std::pow(bits_to_double(c.arg(0), c.arg(1)), bits_to_double(c.arg(2), c.arg(3)))); };
  F["_atan2f"] = [](Core& c) { ret_float(c, std::atan2(bits_to_float(c.arg(0)), bits_to_float(c.arg(1)))); };
  F["_atan2"] = [](Core& c) { ret_double(c, std::atan2(bits_to_double(c.arg(0), c.arg(1)), bits_to_double(c.arg(2), c.arg(3)))); };
  F["_fmodf"] = [](Core& c) { ret_float(c, std::fmod(bits_to_float(c.arg(0)), bits_to_float(c.arg(1)))); };
  F["_fmod"] = [](Core& c) { ret_double(c, std::fmod(bits_to_double(c.arg(0), c.arg(1)), bits_to_double(c.arg(2), c.arg(3)))); };
  (void)rd;
}

}  // namespace astral
