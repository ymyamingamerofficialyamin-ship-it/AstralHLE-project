// AstralHLE core: Mach-O (32-bit ARM) parser.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace astral {

struct Segment { std::string name; uint32_t vmaddr = 0, vmsize = 0, fileoff = 0, filesize = 0, initprot = 0; };
struct Section {
  std::string seg, name; uint32_t addr = 0, size = 0, offset = 0, flags = 0, reserved1 = 0, reserved2 = 0;
  uint32_t type() const { return flags & 0xff; }
};
struct Sym { std::string name; uint8_t type = 0, sect = 0; uint16_t desc = 0; uint32_t value = 0; };
struct ExtReloc { uint32_t addr = 0, symnum = 0; bool ext = false; int length = 0; };

struct MachInfo {
  bool ok = false;
  std::string error;
  bool fat = false;
  uint32_t cputype = 0, cpusubtype = 0, filetype = 0, flags = 0, minos = 0;
  uint32_t slice_off = 0, slice_size = 0;
  std::vector<Segment> segs;
  std::vector<Section> secs;
  std::vector<std::string> dylibs;
  std::vector<Sym> syms;
  std::vector<uint32_t> indirect;
  std::vector<ExtReloc> extrels;
  bool has_unixthread = false; uint32_t entry_pc = 0; bool entry_thumb = false;
  bool has_crypt = false; uint32_t cryptid = 0;
  bool has_dyld_info = false;
  uint32_t first_writable = 0;
  std::string arch_name() const;
};

bool parse_macho(const std::vector<uint8_t>& file, MachInfo& out);

}  // namespace astral
