#include "macho.h"
#include <cstring>

namespace astral {

static uint32_t rd32(const std::vector<uint8_t>& f, size_t o) {
  if (o + 4 > f.size()) return 0;
  return f[o] | (f[o + 1] << 8) | (f[o + 2] << 16) | ((uint32_t)f[o + 3] << 24);
}
static uint32_t rd32be(const std::vector<uint8_t>& f, size_t o) {
  if (o + 4 > f.size()) return 0;
  return ((uint32_t)f[o] << 24) | (f[o + 1] << 16) | (f[o + 2] << 8) | f[o + 3];
}
static std::string fixed(const std::vector<uint8_t>& f, size_t o, size_t n) {
  std::string s;
  for (size_t i = 0; i < n && o + i < f.size() && f[o + i]; i++) s.push_back((char)f[o + i]);
  return s;
}

std::string MachInfo::arch_name() const {
  if (cputype == 0x0100000c) return "arm64";
  if (cputype != 12) return "unknown cpu type " + std::to_string(cputype);
  switch (cpusubtype & 0xff) {
    case 3: return "armv4t?"; case 5: return "armv4t"; case 6: return "armv6"; case 7: return "armv5tej";
    case 8: return "xscale"; case 9: return "armv7"; case 10: return "armv7f"; case 11: return "armv7s"; case 12: return "armv7k";
    default: return "arm (subtype " + std::to_string(cpusubtype) + ")";
  }
}

bool parse_macho(const std::vector<uint8_t>& f, MachInfo& m) {
  m = MachInfo();
  if (f.size() < 28) { m.error = "file too small"; return false; }
  size_t base = 0;
  if (rd32be(f, 0) == 0xcafebabe) {
    m.fat = true;
    uint32_t n = rd32be(f, 4); int best = -1; uint32_t bestsub = 0;
    for (uint32_t i = 0; i < n && i < 16; i++) {
      size_t e = 8 + i * 20;
      uint32_t ct = rd32be(f, e), cs = rd32be(f, e + 4) & 0xff;
      if (ct != 12) continue;
      // prefer the oldest ARM slice (the one this core can run)
      if (best < 0 || cs < bestsub) { best = (int)i; bestsub = cs; }
    }
    if (best < 0) { m.error = "fat binary has no 32-bit ARM slice"; return false; }
    size_t e = 8 + best * 20;
    base = rd32be(f, e + 8); m.slice_off = (uint32_t)base; m.slice_size = rd32be(f, e + 12);
  } else m.slice_size = (uint32_t)f.size();
  uint32_t magic = rd32(f, base);
  if (magic == 0xfeedfacf) { m.cputype = rd32(f, base + 4); m.error = "64-bit Mach-O (arm64): too new for this core"; return false; }
  if (magic != 0xfeedface) { m.error = "not a Mach-O file"; return false; }
  m.cputype = rd32(f, base + 4); m.cpusubtype = rd32(f, base + 8); m.filetype = rd32(f, base + 12);
  uint32_t ncmds = rd32(f, base + 16); m.flags = rd32(f, base + 24);
  size_t off = base + 28;
  uint32_t symoff = 0, nsyms = 0, stroff = 0, strsize = 0, indoff = 0, nind = 0, extoff = 0, next = 0;
  for (uint32_t i = 0; i < ncmds; i++) {
    if (off + 8 > f.size()) break;
    uint32_t cmd = rd32(f, off), sz = rd32(f, off + 4);
    if (sz < 8) break;
    switch (cmd) {
      case 0x1: {
        Segment s; s.name = fixed(f, off + 8, 16);
        s.vmaddr = rd32(f, off + 24); s.vmsize = rd32(f, off + 28); s.fileoff = rd32(f, off + 32); s.filesize = rd32(f, off + 36); s.initprot = rd32(f, off + 44);
        uint32_t nsec = rd32(f, off + 48);
        for (uint32_t k = 0; k < nsec; k++) {
          size_t so = off + 56 + k * 68; Section sec;
          sec.name = fixed(f, so, 16); sec.seg = fixed(f, so + 16, 16);
          sec.addr = rd32(f, so + 32); sec.size = rd32(f, so + 36); sec.offset = rd32(f, so + 40);
          sec.flags = rd32(f, so + 56); sec.reserved1 = rd32(f, so + 60); sec.reserved2 = rd32(f, so + 64);
          m.secs.push_back(sec);
        }
        if ((s.initprot & 2) && !m.first_writable) m.first_writable = s.vmaddr;
        m.segs.push_back(s); break;
      }
      case 0x2: symoff = rd32(f, off + 8); nsyms = rd32(f, off + 12); stroff = rd32(f, off + 16); strsize = rd32(f, off + 20); break;
      case 0xB: indoff = rd32(f, off + 56); nind = rd32(f, off + 60); extoff = rd32(f, off + 64); next = rd32(f, off + 68); break;
      case 0xC: case 0x80000018: case 0x8000001F: { uint32_t no = rd32(f, off + 8); m.dylibs.push_back(fixed(f, off + no, sz - no)); break; }
      case 0x21: m.has_crypt = true; m.cryptid = rd32(f, off + 16); break;
      case 0x25: m.minos = rd32(f, off + 8); break;
      case 0x22: case 0x80000022: m.has_dyld_info = true; break;
      case 0x5: m.has_unixthread = true; m.entry_pc = rd32(f, off + 16 + 15 * 4); m.entry_thumb = rd32(f, off + 16 + 16 * 4) & 0x20; break;
      default: break;
    }
    off += sz;
  }
  for (uint32_t i = 0; i < nsyms; i++) {
    size_t e = base + symoff + (size_t)i * 12; Sym s;
    uint32_t strx = rd32(f, e); s.type = f[e + 4]; s.sect = f[e + 5]; s.desc = f[e + 6] | (f[e + 7] << 8); s.value = rd32(f, e + 8);
    s.name = (strx && stroff + strx < f.size() + base) ? fixed(f, base + stroff + strx, 512) : "";
    m.syms.push_back(s);
  }
  (void)strsize;
  for (uint32_t i = 0; i < nind; i++) m.indirect.push_back(rd32(f, base + indoff + (size_t)i * 4));
  for (uint32_t i = 0; i < next; i++) {
    size_t e = base + extoff + (size_t)i * 8; ExtReloc r;
    r.addr = rd32(f, e); uint32_t info = rd32(f, e + 4);
    r.symnum = info & 0xFFFFFF; r.length = (info >> 25) & 3; r.ext = (info >> 27) & 1;
    m.extrels.push_back(r);
  }
  m.ok = true; return true;
}

}  // namespace astral
