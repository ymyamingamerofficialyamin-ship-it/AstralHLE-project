#include <jni.h>
#include <string>
#include "core.h"

extern "C" JNIEXPORT jstring JNICALL
Java_com_astralhle_app_AstralCore_run(JNIEnv* env, jclass, jstring execPath, jstring deviceModel, jlong maxInsns, jint ramLimitMb) {
  const char* path = env->GetStringUTFChars(execPath, nullptr);
  const char* dev = env->GetStringUTFChars(deviceModel, nullptr);
  std::string report;
  try {
    astral::Core core;
    core.device_model = dev;
    if (ramLimitMb > 0) core.ram_limit_mb = (uint32_t)ramLimitMb;
    report = core.run_report(path, (uint64_t)maxInsns);
  } catch (const std::exception& e) {
    report = std::string("The native core stopped with an error: ") + e.what();
  } catch (...) {
    report = "The native core stopped with an unknown error.";
  }
  env->ReleaseStringUTFChars(execPath, path);
  env->ReleaseStringUTFChars(deviceModel, dev);
  // The report can contain bytes copied from the game's memory. Keep it plain ASCII so the JVM never rejects it.
  for (char& ch : report) {
    unsigned char u = (unsigned char)ch;
    if (u >= 0x80 || (u < 0x20 && ch != '\n' && ch != '\t')) ch = '?';
  }
  return env->NewStringUTF(report.c_str());
}
