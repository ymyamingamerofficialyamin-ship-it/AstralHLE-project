#include "cpu.h"
#include <algorithm>
#include <cmath>
#include <cstring>

namespace astral {

static inline uint32_t ror32(uint32_t v, unsigned n) { n &= 31; return n ? (v >> n) | (v << (32 - n)) : v; }
static inline uint32_t adc32(uint32_t a, uint32_t b, uint32_t cin, bool& c, bool& v) {
  uint64_t u = (uint64_t)a + b + cin;
  uint32_t res = (uint32_t)u;
  c = (u >> 32) & 1;
  v = (((~(a ^ b)) & (a ^ res)) >> 31) & 1;
  return res;
}

bool Cpu::cond_pass(uint32_t c) const {
  switch (c) {
    case 0: return Z;
    case 1: return !Z;
    case 2: return C;
    case 3: return !C;
    case 4: return N;
    case 5: return !N;
    case 6: return V;
    case 7: return !V;
    case 8: return C && !Z;
    case 9: return !C || Z;
    case 10: return N == V;
    case 11: return N != V;
    case 12: return !Z && (N == V);
    case 13: return Z || (N != V);
    default: return true;
  }
}

Stop Cpu::run(uint64_t max) {
  uint64_t end = icount + max;
  while (icount < end) {
    uint32_t pc = r[15];
    if (pc >= TRAP_BASE && pc < TRAP_END) {
      if (pc == RET_SENTINEL) return Stop::Returned;
      trap_index = (pc - TRAP_BASE) >> 2;
      return Stop::Trap;
    }
    ring[ringpos++ & 31] = pc | (thumb ? 1u : 0u);
    Stop s = thumb ? step_thumb() : step_arm();
    icount++;
    if (s != Stop::Running) return s;
    if (mem->fault) return Stop::Fault;
  }
  return Stop::Limit;
}

// ---------------------------------------------------------------- ARM state
Stop Cpu::step_arm() {
  const uint32_t pc = r[15];
  const uint32_t insn = mem->read32(pc);
  last_insn = insn;
  const uint32_t cond = insn >> 28;
  auto RP = [&](unsigned n) -> uint32_t { return n == 15 ? pc + 8 : r[n]; };

  if (cond == 0xF) {
    if ((insn & 0xFE000000) == 0xFA000000) {  // BLX imm
      int32_t off = ((int32_t)(insn << 8)) >> 6;
      off |= ((insn >> 24) & 1) << 1;
      r[14] = pc + 4; thumb = true; r[15] = pc + 8 + off;
      return Stop::Running;
    }
    if ((insn & 0x0D70F000) == 0x0550F000) { r[15] = pc + 4; return Stop::Running; }  // PLD
    undef_note = "unconditional-space instruction"; return Stop::Undefined;
  }
  if (!cond_pass(cond)) { r[15] = pc + 4; return Stop::Running; }
  r[15] = pc + 4;

  // ---- special encodings in the data-processing space
  if ((insn & 0x0FFFFFF0) == 0x012FFF10) {  // BX
    uint32_t t = RP(insn & 15); thumb = t & 1; r[15] = t & ~1u; return Stop::Running;
  }
  if ((insn & 0x0FFFFFF0) == 0x012FFF30) {  // BLX reg
    uint32_t t = RP(insn & 15); r[14] = pc + 4; thumb = t & 1; r[15] = t & ~1u; return Stop::Running;
  }
  if ((insn & 0x0FFF0FF0) == 0x016F0F10) {  // CLZ
    uint32_t v = RP(insn & 15); uint32_t n = 0;
    if (!v) n = 32; else while (!(v & 0x80000000u)) { v <<= 1; n++; }
    r[(insn >> 12) & 15] = n; return Stop::Running;
  }
  if ((insn & 0x0FBF0FFF) == 0x010F0000) {  // MRS
    r[(insn >> 12) & 15] = ((uint32_t)N << 31) | ((uint32_t)Z << 30) | ((uint32_t)C << 29) | ((uint32_t)V << 28) | (thumb ? 0x20u : 0u) | 0x10u;
    return Stop::Running;
  }
  if ((insn & 0x0FB0F000) == 0x0320F000 || (insn & 0x0FB0FFF0) == 0x0120F000) {  // MSR (flags only)
    uint32_t v;
    if (insn & 0x02000000) v = ror32(insn & 0xFF, ((insn >> 8) & 15) * 2); else v = RP(insn & 15);
    if (!(insn & 0x00400000) && (insn & 0x00080000)) { N = v >> 31; Z = (v >> 30) & 1; C = (v >> 29) & 1; V = (v >> 28) & 1; }
    return Stop::Running;
  }
  if ((insn & 0x0FFFFFF0) == 0x0320F000 || insn == 0xE320F000) return Stop::Running;  // NOP / hints

  const uint32_t top = (insn >> 25) & 7;

  // ---- multiply, swap, halfword transfers (000 space with bits 7 and 4 set)
  if (top == 0 && (insn & 0x90) == 0x90) {
    if ((insn & 0x0FC000F0) == 0x00000090) {  // MUL / MLA
      unsigned rd = (insn >> 16) & 15, rn = (insn >> 12) & 15, rs = (insn >> 8) & 15, rm = insn & 15;
      uint32_t res = r[rm] * r[rs];
      if (insn & (1 << 21)) res += r[rn];
      r[rd] = res; if (insn & (1 << 20)) set_nz(res);
      return Stop::Running;
    }
    if ((insn & 0x0F8000F0) == 0x00800090) {  // UMULL/UMLAL/SMULL/SMLAL
      unsigned hi = (insn >> 16) & 15, lo = (insn >> 12) & 15, rs = (insn >> 8) & 15, rm = insn & 15;
      bool sgn = insn & (1 << 22), acc = insn & (1 << 21);
      uint64_t prod = sgn ? (uint64_t)((int64_t)(int32_t)r[rm] * (int64_t)(int32_t)r[rs]) : (uint64_t)r[rm] * (uint64_t)r[rs];
      if (acc) prod += ((uint64_t)r[hi] << 32) | r[lo];
      r[lo] = (uint32_t)prod; r[hi] = (uint32_t)(prod >> 32);
      if (insn & (1 << 20)) { N = r[hi] >> 31; Z = (prod == 0); }
      return Stop::Running;
    }
    if ((insn & 0x0FB00FF0) == 0x01000090) {  // SWP/SWPB
      unsigned rn = (insn >> 16) & 15, rd = (insn >> 12) & 15, rm = insn & 15;
      uint32_t addr = r[rn];
      if (insn & (1 << 22)) { uint8_t t = mem->read8(addr); mem->write8(addr, (uint8_t)r[rm]); r[rd] = t; }
      else { uint32_t t = mem->read32(addr); mem->write32(addr, r[rm]); r[rd] = t; }
      return Stop::Running;
    }
    if (insn & 0x60) {  // LDRH/STRH/LDRSB/LDRSH/LDRD/STRD
      bool P = insn & (1 << 24), U = insn & (1 << 23), Iimm = insn & (1 << 22), W = insn & (1 << 21), L = insn & (1 << 20);
      unsigned rn = (insn >> 16) & 15, rd = (insn >> 12) & 15, sh = (insn >> 5) & 3;
      uint32_t off = Iimm ? (((insn >> 4) & 0xF0) | (insn & 0xF)) : RP(insn & 15);
      uint32_t base = RP(rn);
      uint32_t addr = P ? (U ? base + off : base - off) : base;
      uint32_t nb = U ? base + off : base - off;
      if (!L && sh >= 2) {  // LDRD (sh==2) / STRD (sh==3)
        if (sh == 2) { r[rd] = mem->read32(addr); r[rd + 1] = mem->read32(addr + 4); }
        else { mem->write32(addr, r[rd]); mem->write32(addr + 4, r[rd + 1]); }
        if (!P || W) r[rn] = nb;
        return Stop::Running;
      }
      uint32_t val = 0;
      if (L) {
        if (sh == 1) val = mem->read16(addr);
        else if (sh == 2) val = (uint32_t)(int32_t)(int8_t)mem->read8(addr);
        else val = (uint32_t)(int32_t)(int16_t)mem->read16(addr);
        if (!P || W) r[rn] = nb;
        if (rd == 15) { r[15] = val & ~1u; } else r[rd] = val;
      } else {
        mem->write16(addr, (uint16_t)(rd == 15 ? pc + 12 : r[rd]));
        if (!P || W) r[rn] = nb;
      }
      return Stop::Running;
    }
    undef_note = "unknown 000-space instruction"; return Stop::Undefined;
  }

  // ---- ARMv6 media instructions (extend, reverse)
  if (top == 3 && (insn & 0x10)) {
    unsigned rd = (insn >> 12) & 15, rn = (insn >> 16) & 15, rm = insn & 15;
    unsigned rot = ((insn >> 10) & 3) * 8;
    uint32_t m = ror32(r[rm], rot);
    uint32_t m3 = insn & 0x0FF003F0;
    if (m3 == 0x06A00070) { r[rd] = (uint32_t)(int32_t)(int8_t)m + (rn == 15 ? 0 : r[rn]); return Stop::Running; }
    if (m3 == 0x06B00070) { r[rd] = (uint32_t)(int32_t)(int16_t)m + (rn == 15 ? 0 : r[rn]); return Stop::Running; }
    if (m3 == 0x06E00070) { r[rd] = (m & 0xFF) + (rn == 15 ? 0 : r[rn]); return Stop::Running; }
    if (m3 == 0x06F00070) { r[rd] = (m & 0xFFFF) + (rn == 15 ? 0 : r[rn]); return Stop::Running; }
    if ((insn & 0x0FFF0FF0) == 0x06BF0F30) { uint32_t v = r[rm]; r[rd] = (v >> 24) | ((v >> 8) & 0xFF00) | ((v << 8) & 0xFF0000) | (v << 24); return Stop::Running; }
    if ((insn & 0x0FFF0FF0) == 0x06BF0FB0) { uint32_t v = r[rm]; r[rd] = ((v >> 8) & 0x00FF00FF) | ((v << 8) & 0xFF00FF00); return Stop::Running; }
    if ((insn & 0x0FFF0FF0) == 0x06FF0FB0) { uint32_t v = r[rm]; r[rd] = (uint32_t)(int32_t)(int16_t)(((v & 0xFF) << 8) | ((v >> 8) & 0xFF)); return Stop::Running; }
    undef_note = "unsupported ARMv6 media instruction"; return Stop::Undefined;
  }

  // ---- data processing
  if (top == 0 || top == 1) {
    unsigned op = (insn >> 21) & 15, rn = (insn >> 16) & 15, rd = (insn >> 12) & 15;
    bool S = insn & (1 << 20);
    bool carry = C;
    uint32_t op2;
    bool regshift = false;
    if (insn & (1 << 25)) {
      unsigned rot = ((insn >> 8) & 15) * 2;
      op2 = ror32(insn & 0xFF, rot);
      if (rot) carry = op2 >> 31;
    } else {
      unsigned rm = insn & 15, type = (insn >> 5) & 3;
      uint32_t val; uint32_t amt;
      if (insn & 0x10) {
        regshift = true;
        val = rm == 15 ? pc + 12 : r[rm];
        amt = r[(insn >> 8) & 15] & 0xFF;
        if (amt == 0) { op2 = val; }
        else switch (type) {
          case 0: if (amt < 32) { carry = (val >> (32 - amt)) & 1; op2 = val << amt; } else if (amt == 32) { carry = val & 1; op2 = 0; } else { carry = 0; op2 = 0; } break;
          case 1: if (amt < 32) { carry = (val >> (amt - 1)) & 1; op2 = val >> amt; } else if (amt == 32) { carry = val >> 31; op2 = 0; } else { carry = 0; op2 = 0; } break;
          case 2: if (amt < 32) { carry = ((int32_t)val >> (amt - 1)) & 1; op2 = (uint32_t)((int32_t)val >> amt); } else { carry = val >> 31; op2 = (uint32_t)((int32_t)val >> 31); } break;
          default: { unsigned a = amt & 31; if (a == 0) { carry = val >> 31; op2 = val; } else { op2 = ror32(val, a); carry = op2 >> 31; } }
        }
      } else {
        val = RP(rm); amt = (insn >> 7) & 31;
        switch (type) {
          case 0: if (amt) { carry = (val >> (32 - amt)) & 1; op2 = val << amt; } else op2 = val; break;
          case 1: if (amt) { carry = (val >> (amt - 1)) & 1; op2 = val >> amt; } else { carry = val >> 31; op2 = 0; } break;
          case 2: if (amt) { carry = ((int32_t)val >> (amt - 1)) & 1; op2 = (uint32_t)((int32_t)val >> amt); } else { carry = val >> 31; op2 = (uint32_t)((int32_t)val >> 31); } break;
          default: if (amt) { op2 = ror32(val, amt); carry = op2 >> 31; } else { op2 = ((uint32_t)C << 31) | (val >> 1); carry = val & 1; }
        }
      }
    }
    uint32_t a = (rn == 15) ? (regshift ? pc + 12 : pc + 8) : r[rn];
    uint32_t res = 0; bool c2 = C, v2 = V; bool logical = false;
    switch (op) {
      case 0: res = a & op2; logical = true; break;
      case 1: res = a ^ op2; logical = true; break;
      case 2: res = adc32(a, ~op2, 1, c2, v2); break;
      case 3: res = adc32(op2, ~a, 1, c2, v2); break;
      case 4: res = adc32(a, op2, 0, c2, v2); break;
      case 5: res = adc32(a, op2, C, c2, v2); break;
      case 6: res = adc32(a, ~op2, C, c2, v2); break;
      case 7: res = adc32(op2, ~a, C, c2, v2); break;
      case 8: res = a & op2; logical = true; break;
      case 9: res = a ^ op2; logical = true; break;
      case 10: res = adc32(a, ~op2, 1, c2, v2); break;
      case 11: res = adc32(a, op2, 0, c2, v2); break;
      case 12: res = a | op2; logical = true; break;
      case 13: res = op2; logical = true; break;
      case 14: res = a & ~op2; logical = true; break;
      default: res = ~op2; logical = true; break;
    }
    bool writes = !(op >= 8 && op <= 11);
    if (S || !writes) {
      if (!(rd == 15 && writes)) {
        set_nz(res);
        if (logical) C = carry; else { C = c2; V = v2; }
      }
    }
    if (writes) { if (rd == 15) r[15] = res & ~3u; else r[rd] = res; }
    return Stop::Running;
  }

  // ---- single data transfer
  if (top == 2 || top == 3) {
    bool Ireg = insn & (1 << 25), P = insn & (1 << 24), U = insn & (1 << 23), B = insn & (1 << 22), W = insn & (1 << 21), L = insn & (1 << 20);
    unsigned rn = (insn >> 16) & 15, rd = (insn >> 12) & 15;
    uint32_t off;
    if (!Ireg) off = insn & 0xFFF;
    else {
      uint32_t val = RP(insn & 15); unsigned amt = (insn >> 7) & 31, type = (insn >> 5) & 3;
      switch (type) {
        case 0: off = val << amt; break;
        case 1: off = amt ? val >> amt : 0; break;
        case 2: off = amt ? (uint32_t)((int32_t)val >> amt) : (uint32_t)((int32_t)val >> 31); break;
        default: off = amt ? ror32(val, amt) : (((uint32_t)C << 31) | (val >> 1));
      }
    }
    uint32_t base = RP(rn);
    uint32_t nb = U ? base + off : base - off;
    uint32_t addr = P ? nb : base;
    if (L) {
      uint32_t val = B ? mem->read8(addr) : mem->read32(addr);
      if (!P || W) r[rn] = nb;
      if (rd == 15) { thumb = val & 1; r[15] = val & ~1u; } else r[rd] = val;
    } else {
      uint32_t val = (rd == 15) ? pc + 12 : r[rd];
      if (B) mem->write8(addr, (uint8_t)val); else mem->write32(addr, val);
      if (!P || W) r[rn] = nb;
    }
    return Stop::Running;
  }

  // ---- block data transfer
  if (top == 4) {
    bool P = insn & (1 << 24), U = insn & (1 << 23), W = insn & (1 << 21), L = insn & (1 << 20);
    unsigned rn = (insn >> 16) & 15; uint32_t list = insn & 0xFFFF;
    unsigned cnt = __builtin_popcount(list);
    uint32_t base = RP(rn);
    uint32_t start = U ? (P ? base + 4 : base) : (P ? base - 4 * cnt : base - 4 * cnt + 4);
    uint32_t nb = U ? base + 4 * cnt : base - 4 * cnt;
    uint32_t addr = start;
    for (unsigned i = 0; i < 16; i++) {
      if (!(list & (1u << i))) continue;
      if (L) {
        uint32_t v = mem->read32(addr);
        if (i == 15) { thumb = v & 1; r[15] = v & ~1u; } else r[i] = v;
      } else mem->write32(addr, i == 15 ? pc + 12 : (i == rn ? base : r[i]));
      addr += 4;
    }
    if (W && !(L && (list & (1u << rn)))) r[rn] = nb;
    return Stop::Running;
  }

  // ---- branch
  if (top == 5) {
    int32_t off = ((int32_t)(insn << 8)) >> 6;
    if (insn & (1 << 24)) r[14] = pc + 4;
    r[15] = pc + 8 + off;
    return Stop::Running;
  }

  // ---- coprocessor / SWI
  if (top == 7) {
    if (insn & (1 << 24)) { swi_num = insn & 0xFFFFFF; return Stop::Swi; }
    unsigned cp = (insn >> 8) & 15;
    if ((insn & 0x10) && cp == 15) {  // MRC/MCR p15
      unsigned crn = (insn >> 16) & 15, crm = insn & 15, op2 = (insn >> 5) & 7, rt = (insn >> 12) & 15;
      bool toarm = insn & (1 << 20);
      if (crn == 13 && crm == 0 && op2 == 3) { if (toarm) r[rt] = tls; else tls = r[rt]; }
      else if (toarm) r[rt] = 0;   // ID registers etc.
      return Stop::Running;         // cache maintenance etc. are no-ops
    }
    if (cp == 10 || cp == 11) return step_vfp(insn, pc);
    undef_note = "coprocessor instruction"; return Stop::Undefined;
  }
  if (top == 6) {
    unsigned cp = (insn >> 8) & 15;
    if (cp == 10 || cp == 11 || (insn & 0x0FE00000) == 0x0C400000) return step_vfp(insn, pc);
    undef_note = "coprocessor load/store"; return Stop::Undefined;
  }
  undef_note = "unknown instruction"; return Stop::Undefined;
}

// ---------------------------------------------------------------- Thumb state
Stop Cpu::step_thumb() {
  const uint32_t pc = r[15];
  const uint32_t h = mem->read16(pc);
  last_insn = h;
  r[15] = pc + 2;
  const uint32_t pc4 = pc + 4;
  auto RT = [&](unsigned n) -> uint32_t { return n == 15 ? pc4 : r[n]; };
  auto flags_logic = [&](uint32_t v) { set_nz(v); };

  switch (h >> 11) {
    case 0: case 1: case 2: {  // shift by immediate
      unsigned op = (h >> 11) & 3, rs = (h >> 3) & 7, rd = h & 7, amt = (h >> 6) & 31;
      uint32_t v = r[rs], res;
      if (op == 0) { if (amt) { C = (v >> (32 - amt)) & 1; res = v << amt; } else res = v; }
      else if (op == 1) { if (amt) { C = (v >> (amt - 1)) & 1; res = v >> amt; } else { C = v >> 31; res = 0; } }
      else { if (amt) { C = ((int32_t)v >> (amt - 1)) & 1; res = (uint32_t)((int32_t)v >> amt); } else { C = v >> 31; res = (uint32_t)((int32_t)v >> 31); } }
      r[rd] = res; flags_logic(res); return Stop::Running;
    }
    case 3: {  // add/subtract
      unsigned rd = h & 7, rs = (h >> 3) & 7; bool imm = h & (1 << 10), sub = h & (1 << 9);
      uint32_t b = imm ? ((h >> 6) & 7) : r[(h >> 6) & 7], a = r[rs], res; bool c, v;
      res = sub ? adc32(a, ~b, 1, c, v) : adc32(a, b, 0, c, v);
      r[rd] = res; set_nz(res); C = c; V = v; return Stop::Running;
    }
    case 4: case 5: case 6: case 7: {  // mov/cmp/add/sub imm8
      unsigned op = (h >> 11) & 3, rd = (h >> 8) & 7; uint32_t imm = h & 0xFF, a = r[rd], res; bool c, v;
      if (op == 0) { res = imm; set_nz(res); r[rd] = res; return Stop::Running; }
      if (op == 1) { res = adc32(a, ~imm, 1, c, v); set_nz(res); C = c; V = v; return Stop::Running; }
      res = op == 2 ? adc32(a, imm, 0, c, v) : adc32(a, ~imm, 1, c, v);
      r[rd] = res; set_nz(res); C = c; V = v; return Stop::Running;
    }
    case 8: {
      if ((h >> 10) == 0x10) {  // ALU operations
        unsigned op = (h >> 6) & 15, rs = (h >> 3) & 7, rd = h & 7; uint32_t a = r[rd], b = r[rs], res = 0; bool c = C, v = V; bool arith = false, wr = true;
        switch (op) {
          case 0: res = a & b; break;
          case 1: res = a ^ b; break;
          case 2: { unsigned s = b & 0xFF; if (!s) res = a; else if (s < 32) { C = (a >> (32 - s)) & 1; res = a << s; } else if (s == 32) { C = a & 1; res = 0; } else { C = 0; res = 0; } break; }
          case 3: { unsigned s = b & 0xFF; if (!s) res = a; else if (s < 32) { C = (a >> (s - 1)) & 1; res = a >> s; } else if (s == 32) { C = a >> 31; res = 0; } else { C = 0; res = 0; } break; }
          case 4: { unsigned s = b & 0xFF; if (!s) res = a; else if (s < 32) { C = ((int32_t)a >> (s - 1)) & 1; res = (uint32_t)((int32_t)a >> s); } else { C = a >> 31; res = (uint32_t)((int32_t)a >> 31); } break; }
          case 5: res = adc32(a, b, C, c, v); arith = true; break;
          case 6: res = adc32(a, ~b, C, c, v); arith = true; break;
          case 7: { unsigned s = b & 0xFF; if (!s) res = a; else { s &= 31; if (!s) { C = a >> 31; res = a; } else { res = ror32(a, s); C = res >> 31; } } break; }
          case 8: res = a & b; wr = false; break;
          case 9: res = adc32(0, ~b, 1, c, v); arith = true; break;
          case 10: res = adc32(a, ~b, 1, c, v); arith = true; wr = false; break;
          case 11: res = adc32(a, b, 0, c, v); arith = true; wr = false; break;
          case 12: res = a | b; break;
          case 13: res = a * b; break;
          case 14: res = a & ~b; break;
          default: res = ~b; break;
        }
        set_nz(res); if (arith) { C = c; V = v; }
        if (wr) r[rd] = res;
        return Stop::Running;
      }
      if ((h >> 10) == 0x11) {  // hi register operations
        unsigned op = (h >> 8) & 3, rd = ((h >> 4) & 8) | (h & 7), rs = (h >> 3) & 15;
        uint32_t b = RT(rs);
        if (op == 0) { uint32_t res = RT(rd) + b; if (rd == 15) r[15] = res & ~1u; else r[rd] = res; return Stop::Running; }
        if (op == 1) { bool c, v; uint32_t res = adc32(RT(rd), ~b, 1, c, v); set_nz(res); C = c; V = v; return Stop::Running; }
        if (op == 2) { if (rd == 15) r[15] = b & ~1u; else r[rd] = b; return Stop::Running; }
        if (h & 0x80) r[14] = (pc + 2) | 1;  // BLX reg
        thumb = b & 1; r[15] = b & ~1u; return Stop::Running;
      }
      undef_note = "thumb 0100 00/01 decode"; return Stop::Undefined;
    }
    case 9: {  // LDR PC-relative
      unsigned rd = (h >> 8) & 7; uint32_t addr = (pc4 & ~3u) + (h & 0xFF) * 4;
      r[rd] = mem->read32(addr); return Stop::Running;
    }
    case 10: case 11: {  // load/store register offset
      unsigned op = (h >> 9) & 7, rm = (h >> 6) & 7, rn = (h >> 3) & 7, rd = h & 7; uint32_t addr = r[rn] + r[rm];
      switch (op) {
        case 0: mem->write32(addr, r[rd]); break;
        case 1: mem->write16(addr, (uint16_t)r[rd]); break;
        case 2: mem->write8(addr, (uint8_t)r[rd]); break;
        case 3: r[rd] = (uint32_t)(int32_t)(int8_t)mem->read8(addr); break;
        case 4: r[rd] = mem->read32(addr); break;
        case 5: r[rd] = mem->read16(addr); break;
        case 6: r[rd] = mem->read8(addr); break;
        default: r[rd] = (uint32_t)(int32_t)(int16_t)mem->read16(addr); break;
      }
      return Stop::Running;
    }
    case 12: case 13: case 14: case 15: {  // load/store word/byte immediate
      unsigned rn = (h >> 3) & 7, rd = h & 7, imm = (h >> 6) & 31; bool B = h & (1 << 12), L = h & (1 << 11);
      uint32_t addr = r[rn] + (B ? imm : imm * 4);
      if (L) r[rd] = B ? mem->read8(addr) : mem->read32(addr);
      else if (B) mem->write8(addr, (uint8_t)r[rd]); else mem->write32(addr, r[rd]);
      return Stop::Running;
    }
    case 16: case 17: {  // halfword immediate
      unsigned rn = (h >> 3) & 7, rd = h & 7, imm = ((h >> 6) & 31) * 2; uint32_t addr = r[rn] + imm;
      if (h & (1 << 11)) r[rd] = mem->read16(addr); else mem->write16(addr, (uint16_t)r[rd]);
      return Stop::Running;
    }
    case 18: case 19: {  // SP-relative
      unsigned rd = (h >> 8) & 7; uint32_t addr = r[13] + (h & 0xFF) * 4;
      if (h & (1 << 11)) r[rd] = mem->read32(addr); else mem->write32(addr, r[rd]);
      return Stop::Running;
    }
    case 20: case 21: {  // ADD Rd, PC/SP, #imm
      unsigned rd = (h >> 8) & 7; uint32_t imm = (h & 0xFF) * 4;
      r[rd] = (h & (1 << 11)) ? r[13] + imm : (pc4 & ~3u) + imm; return Stop::Running;
    }
    case 22: case 23: {  // miscellaneous
      if ((h & 0xFF00) == 0xB000) { uint32_t imm = (h & 0x7F) * 4; if (h & 0x80) r[13] -= imm; else r[13] += imm; return Stop::Running; }
      if ((h & 0xFE00) == 0xB400) {  // PUSH
        uint32_t list = h & 0xFF; unsigned cnt = __builtin_popcount(list) + ((h >> 8) & 1);
        uint32_t sp = r[13] - 4 * cnt, a = sp;
        for (unsigned i = 0; i < 8; i++) if (list & (1u << i)) { mem->write32(a, r[i]); a += 4; }
        if (h & 0x100) mem->write32(a, r[14]);
        r[13] = sp; return Stop::Running;
      }
      if ((h & 0xFE00) == 0xBC00) {  // POP
        uint32_t a = r[13];
        for (unsigned i = 0; i < 8; i++) if (h & (1u << i)) { r[i] = mem->read32(a); a += 4; }
        if (h & 0x100) { uint32_t v = mem->read32(a); a += 4; thumb = v & 1; r[15] = v & ~1u; }
        r[13] = a; return Stop::Running;
      }
      if ((h & 0xFF00) == 0xB200) {  // SXTH SXTB UXTH UXTB
        uint32_t v = r[(h >> 3) & 7]; unsigned rd = h & 7;
        switch ((h >> 6) & 3) { case 0: r[rd] = (uint32_t)(int32_t)(int16_t)v; break; case 1: r[rd] = (uint32_t)(int32_t)(int8_t)v; break; case 2: r[rd] = v & 0xFFFF; break; default: r[rd] = v & 0xFF; }
        return Stop::Running;
      }
      if ((h & 0xFF00) == 0xBA00) {  // REV REV16 REVSH
        uint32_t v = r[(h >> 3) & 7]; unsigned rd = h & 7; unsigned o = (h >> 6) & 3;
        if (o == 0) r[rd] = (v >> 24) | ((v >> 8) & 0xFF00) | ((v << 8) & 0xFF0000) | (v << 24);
        else if (o == 1) r[rd] = ((v >> 8) & 0x00FF00FF) | ((v << 8) & 0xFF00FF00);
        else r[rd] = (uint32_t)(int32_t)(int16_t)(((v & 0xFF) << 8) | ((v >> 8) & 0xFF));
        return Stop::Running;
      }
      if ((h & 0xFFE8) == 0xB660 || h == 0xBF00) return Stop::Running;  // CPS, NOP
      undef_note = "thumb misc (BKPT or unsupported)"; return Stop::Undefined;
    }
    case 24: case 25: {  // LDMIA/STMIA
      unsigned rn = (h >> 8) & 7; uint32_t a = r[rn]; bool L = h & (1 << 11); uint32_t list = h & 0xFF;
      for (unsigned i = 0; i < 8; i++) if (list & (1u << i)) { if (L) r[i] = mem->read32(a); else mem->write32(a, r[i]); a += 4; }
      if (!(L && (list & (1u << rn)))) r[rn] = a;
      return Stop::Running;
    }
    case 26: case 27: {  // conditional branch / SWI
      unsigned c = (h >> 8) & 15;
      if (c == 15) { swi_num = h & 0xFF; return Stop::Swi; }
      if (c == 14) { undef_note = "thumb undefined (cond 1110)"; return Stop::Undefined; }
      if (cond_pass(c)) r[15] = pc4 + (uint32_t)((int32_t)(int8_t)(h & 0xFF) * 2);
      return Stop::Running;
    }
    case 28: {  // unconditional branch
      int32_t off = (int32_t)((h & 0x7FF) << 21) >> 20;
      r[15] = pc4 + off; return Stop::Running;
    }
    case 29: {  // BLX suffix
      uint32_t t = (r[14] + ((h & 0x7FF) << 1)) & ~3u;
      r[14] = (pc + 2) | 1; thumb = false; r[15] = t; return Stop::Running;
    }
    case 30: {  // BL prefix
      int32_t off = (int32_t)((h & 0x7FF) << 21) >> 9;
      r[14] = pc4 + off; return Stop::Running;
    }
    default: {  // 31: BL suffix
      uint32_t t = r[14] + ((h & 0x7FF) << 1);
      r[14] = (pc + 2) | 1; r[15] = t; return Stop::Running;
    }
  }
}


// ---------------------------------------------------------------- VFPv2
static inline float u2f(uint32_t v) { float f; memcpy(&f, &v, 4); return f; }
static inline uint32_t f2u(float f) { uint32_t v; memcpy(&v, &f, 4); return v; }
static inline double u2d(uint64_t v) { double d; memcpy(&d, &v, 8); return d; }
static inline uint64_t d2u(double d) { uint64_t v; memcpy(&v, &d, 8); return v; }

Stop Cpu::step_vfp(uint32_t insn, uint32_t pc) {
  const bool dbl = ((insn >> 8) & 15) == 11;
  auto getD = [&](unsigned n) -> uint64_t { return (uint64_t)s[n * 2] | ((uint64_t)s[n * 2 + 1] << 32); };
  auto setD = [&](unsigned n, uint64_t v) { s[n * 2] = (uint32_t)v; s[n * 2 + 1] = (uint32_t)(v >> 32); };
  const unsigned vd = (insn >> 12) & 15, vn = (insn >> 16) & 15, vm = insn & 15;
  const unsigned D = (insn >> 22) & 1, Nb = (insn >> 7) & 1, M = (insn >> 5) & 1;
  const unsigned sd = (vd << 1) | D, sn = (vn << 1) | Nb, sm = (vm << 1) | M;
  const unsigned dd = (D << 4) | vd, dn = (Nb << 4) | vn, dm = (M << 4) | vm;
  const unsigned top = (insn >> 25) & 7;

  if (top == 6) {
    if ((insn & 0x0FE00000) == 0x0C400000) {  // VMOV core <-> VFP, two registers
      unsigned rt = (insn >> 12) & 15, rt2 = (insn >> 16) & 15; bool toarm = insn & (1 << 20);
      if (dbl) { if (toarm) { r[rt] = s[dm * 2]; r[rt2] = s[dm * 2 + 1]; } else { s[dm * 2] = r[rt]; s[dm * 2 + 1] = r[rt2]; } }
      else { if (toarm) { r[rt] = s[sm]; r[rt2] = s[sm + 1]; } else { s[sm] = r[rt]; s[sm + 1] = r[rt2]; } }
      return Stop::Running;
    }
    bool P = insn & (1 << 24), U = insn & (1 << 23), W = insn & (1 << 21), L = insn & (1 << 20);
    unsigned rn = (insn >> 16) & 15, imm = insn & 0xFF;
    uint32_t base = rn == 15 ? ((pc + 8) & ~3u) : r[rn];
    if (P && !W) {  // VLDR / VSTR
      uint32_t addr = U ? base + imm * 4 : base - imm * 4;
      if (dbl) { if (L) { setD(dd, (uint64_t)mem->read32(addr) | ((uint64_t)mem->read32(addr + 4) << 32)); } else { uint64_t v = getD(dd); mem->write32(addr, (uint32_t)v); mem->write32(addr + 4, (uint32_t)(v >> 32)); } }
      else { if (L) s[sd] = mem->read32(addr); else mem->write32(addr, s[sd]); }
      return Stop::Running;
    }
    // VLDM / VSTM (and VPUSH / VPOP)
    uint32_t start = U ? base : base - imm * 4;
    uint32_t addr = start;
    if (dbl) { unsigned count = imm / 2; for (unsigned i = 0; i < count; i++) { unsigned reg = dd + i; if (L) { setD(reg & 31, (uint64_t)mem->read32(addr) | ((uint64_t)mem->read32(addr + 4) << 32)); } else { uint64_t v = getD(reg & 31); mem->write32(addr, (uint32_t)v); mem->write32(addr + 4, (uint32_t)(v >> 32)); } addr += 8; } }
    else { for (unsigned i = 0; i < imm; i++) { unsigned reg = (sd + i) & 63; if (L) s[reg] = mem->read32(addr); else mem->write32(addr, s[reg]); addr += 4; } }
    if (W) r[rn] = U ? base + imm * 4 : base - imm * 4;
    return Stop::Running;
  }

  // top == 7
  if (insn & 0x10) {  // register transfers
    unsigned rt = (insn >> 12) & 15;
    if ((insn & 0x0FE00F7F) == 0x0E000A10) { if (insn & (1 << 20)) r[rt] = s[sn]; else s[sn] = rt == 15 ? pc + 8 : r[rt]; return Stop::Running; }  // VMOV Sn <-> Rt
    if ((insn & 0x0FFF0FFF) == 0x0EF10A10) {  // VMRS
      if (rt == 15) { N = fpscr >> 31; Z = (fpscr >> 30) & 1; C = (fpscr >> 29) & 1; V = (fpscr >> 28) & 1; } else r[rt] = fpscr;
      return Stop::Running;
    }
    if ((insn & 0x0FFF0FFF) == 0x0EE10A10) { fpscr = r[rt]; return Stop::Running; }  // VMSR
    undef_note = "unsupported VFP register transfer"; return Stop::Undefined;
  }

  unsigned opc1 = ((insn >> 20) & 0xB) | 0;   // bits 23,21,20 (bit22 is D)
  unsigned opbits = (insn >> 6) & 1;
  auto binop = [&](int kind) {  // kind: 0 add 1 sub 2 mul 3 nmul 4 div 5 mla 6 mls 7 nmla 8 nmls
    if (dbl) {
      double a = u2d(getD(dn)), b = u2d(getD(dm)), acc = u2d(getD(dd)), res = 0;
      switch (kind) { case 0: res = a + b; break; case 1: res = a - b; break; case 2: res = a * b; break; case 3: res = -(a * b); break; case 4: res = a / b; break;
        case 5: res = acc + a * b; break; case 6: res = acc - a * b; break; case 7: res = -acc - a * b; break; default: res = -acc + a * b; }
      setD(dd, d2u(res));
    } else {
      float a = u2f(s[sn]), b = u2f(s[sm]), acc = u2f(s[sd]), res = 0;
      switch (kind) { case 0: res = a + b; break; case 1: res = a - b; break; case 2: res = a * b; break; case 3: res = -(a * b); break; case 4: res = a / b; break;
        case 5: res = acc + a * b; break; case 6: res = acc - a * b; break; case 7: res = -acc - a * b; break; default: res = -acc + a * b; }
      s[sd] = f2u(res);
    }
  };
  switch (opc1) {
    case 0x0: binop(opbits ? 6 : 5); return Stop::Running;     // VMLA / VMLS
    case 0x1: binop(opbits ? 7 : 8); return Stop::Running;     // VNMLS(0) / VNMLA(1)
    case 0x2: binop(opbits ? 3 : 2); return Stop::Running;     // VMUL / VNMUL
    case 0x3: binop(opbits ? 1 : 0); return Stop::Running;     // VADD / VSUB
    case 0x8: binop(4); return Stop::Running;                  // VDIV
    case 0xB: break;
    default: undef_note = "unsupported VFP data-processing instruction"; return Stop::Undefined;
  }
  unsigned opc2 = vn, opc3 = (insn >> 6) & 3;
  auto setflags = [&](double a, double b, bool unordered) {
    uint32_t f = unordered ? 0x30000000u : (a == b ? 0x60000000u : (a < b ? 0x80000000u : 0x20000000u));
    fpscr = (fpscr & 0x0FFFFFFFu) | f;
  };
  switch (opc2) {
    case 0:  // VMOV reg / VABS
      if (opc3 == 1) { if (dbl) setD(dd, getD(dm)); else s[sd] = s[sm]; return Stop::Running; }
      if (opc3 == 3) { if (dbl) setD(dd, getD(dm) & 0x7FFFFFFFFFFFFFFFull); else s[sd] = s[sm] & 0x7FFFFFFFu; return Stop::Running; }
      break;
    case 1:  // VNEG / VSQRT
      if (opc3 == 1) { if (dbl) setD(dd, getD(dm) ^ 0x8000000000000000ull); else s[sd] = s[sm] ^ 0x80000000u; return Stop::Running; }
      if (opc3 == 3) { if (dbl) setD(dd, d2u(sqrt(u2d(getD(dm))))); else s[sd] = f2u(sqrtf(u2f(s[sm]))); return Stop::Running; }
      break;
    case 4: case 5: {  // VCMP / VCMPE (register or with zero)
      double a = dbl ? u2d(getD(dd)) : (double)u2f(s[sd]);
      double b = opc2 == 5 ? 0.0 : (dbl ? u2d(getD(dm)) : (double)u2f(s[sm]));
      setflags(a, b, a != a || b != b); return Stop::Running;
    }
    case 7:  // VCVT between double and single
      if (opc3 == 3) {
        if (dbl) s[sd] = f2u((float)u2d(getD(dm)));   // F32.F64
        else setD(dd, d2u((double)u2f(s[sm])));        // F64.F32
        return Stop::Running;
      }
      break;
    case 8:  // VCVT integer -> float
      if (opc3 & 1) {
        bool sgn = insn & (1 << 7); uint32_t iv = s[sm];
        double v = sgn ? (double)(int32_t)iv : (double)iv;
        if (dbl) setD(dd, d2u(v)); else s[sd] = f2u((float)v);
        return Stop::Running;
      }
      break;
    case 12: case 13: {  // VCVT float -> integer (12: unsigned, 13: signed)
      double v = dbl ? u2d(getD(dm)) : (double)u2f(s[sm]);
      bool to_zero = insn & (1 << 7);
      if (!to_zero) v = nearbyint(v); else v = std::trunc(v);
      uint32_t out;
      if (v != v) out = 0;
      else if (opc2 == 13) out = v >= 2147483647.0 ? 0x7FFFFFFFu : (v <= -2147483648.0 ? 0x80000000u : (uint32_t)(int32_t)v);
      else out = v <= 0 ? 0 : (v >= 4294967295.0 ? 0xFFFFFFFFu : (uint32_t)v);
      s[sd] = out; return Stop::Running;
    }
    default: break;
  }
  undef_note = "unsupported VFP extension instruction"; return Stop::Undefined;
}

}  // namespace astral
