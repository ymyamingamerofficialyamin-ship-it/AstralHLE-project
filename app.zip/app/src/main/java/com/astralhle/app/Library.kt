package com.astralhle.app

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Collections
import java.util.UUID
import java.util.zip.ZipFile

data class Game(val id: String, val name: String, val hasIcon: Boolean)

/** Stores imported IPA files and the info shown on the home screen. */
object Library {
    private fun dir(c: Context) = File(c.filesDir, "games").apply { mkdirs() }
    fun ipaFile(c: Context, g: Game) = File(dir(c), g.id + ".ipa")
    fun iconFile(c: Context, g: Game) = File(dir(c), g.id + ".png")

    fun list(c: Context): List<Game> {
        val arr = JSONArray(Prefs.gamesJson(c))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Game(o.getString("id"), o.getString("name"), o.optBoolean("icon", false))
        }
    }

    private fun save(c: Context, l: List<Game>) {
        val arr = JSONArray()
        l.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name).put("icon", it.hasIcon)) }
        Prefs.setGamesJson(c, arr.toString())
    }

    fun remove(c: Context, g: Game) {
        ipaFile(c, g).delete(); iconFile(c, g).delete()
        if (Prefs.recentId(c) == g.id) Prefs.setStr(c, "recent", null)
        save(c, list(c).filter { it.id != g.id })
    }

    /** Extracts the game's Mach-O executable from its IPA so the native core can read it. */
    fun extractExecutable(c: Context, g: Game): File? {
        return try {
            ZipFile(ipaFile(c, g)).use { zip ->
                val entries = Collections.list(zip.entries())
                val plistEntry = entries.firstOrNull { Regex("^Payload/[^/]+\\.app/Info\\.plist$").matches(it.name) } ?: return null
                val appDir = plistEntry.name.removeSuffix("Info.plist")
                val info = Plist.parse(zip.getInputStream(plistEntry).readBytes())
                val exe = info["CFBundleExecutable"] as? String ?: return null
                val entry = zip.getEntry(appDir + exe) ?: return null
                val out = File(c.cacheDir, "exec_" + g.id)
                zip.getInputStream(entry).use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                out
            }
        } catch (e: Exception) { null }
    }

    private val infoRegex = Regex("^Payload/[^/]+\\.app/Info\\.plist$")

    /** true = the game asks for portrait, false = landscape, null = the IPA does not say. */
    fun orientationOf(c: Context, g: Game): Boolean? {
        return try {
            ZipFile(ipaFile(c, g)).use { zip ->
                val e = Collections.list(zip.entries()).firstOrNull { infoRegex.matches(it.name) } ?: return null
                val info = Plist.parse(zip.getInputStream(e).readBytes())
                val single = info["UIInterfaceOrientation"] as? String
                val list = info["UISupportedInterfaceOrientations"] as? List<*>
                val s = single ?: (list?.firstOrNull() as? String)
                when {
                    s == null -> null
                    s.contains("Landscape") -> false
                    s.contains("Portrait") -> true
                    else -> null
                }
            }
        } catch (e: Exception) { null }
    }

    /** The game's own launch image (Default.png), if it has a real one. */
    fun splashOf(c: Context, g: Game): Bitmap? {
        return try {
            ZipFile(ipaFile(c, g)).use { zip ->
                val entries = Collections.list(zip.entries())
                val plist = entries.firstOrNull { infoRegex.matches(it.name) } ?: return null
                val appDir = plist.name.removeSuffix("Info.plist")
                val best = entries.filter {
                    it.name.startsWith(appDir) && it.name.removePrefix(appDir).let { n ->
                        !n.contains('/') && n.endsWith(".png", true) && (n.startsWith("Default", true) || n.startsWith("LaunchImage", true))
                    }
                }.maxByOrNull { it.size } ?: return null
                val bmp = IconDecoder.decode(zip.getInputStream(best).readBytes()) ?: return null
                if (bmp.width < 100 || bmp.height < 100) return null
                // ignore nearly black images (some games ship an empty Default.png)
                val tiny = Bitmap.createScaledBitmap(bmp, 8, 8, true); var sum = 0L
                for (y in 0 until 8) for (x in 0 until 8) { val p = tiny.getPixel(x, y); sum += ((p shr 16) and 255) + ((p shr 8) and 255) + (p and 255) }
                if (sum / (64 * 3) < 14) null else bmp
            }
        } catch (e: Exception) { null }
    }

    fun find(c: Context, id: String?): Game? = if (id == null) null else list(c).firstOrNull { it.id == id }

    /** Copies the IPA into app storage and reads its name and icon. Run off the UI thread. */
    fun import(c: Context, uri: Uri, fallbackName: String): Game {
        val id = UUID.randomUUID().toString()
        val ipa = File(dir(c), "$id.ipa")
        val input = c.contentResolver.openInputStream(uri) ?: throw IllegalStateException("Cannot open file")
        input.use { i -> ipa.outputStream().use { o -> i.copyTo(o) } }
        try {
            return ZipFile(ipa).use { zip ->
                val entries = Collections.list(zip.entries())
                val plistEntry = entries.firstOrNull { Regex("^Payload/[^/]+\\.app/Info\\.plist$").matches(it.name) }
                    ?: throw IllegalStateException("This is not a valid IPA file")
                val appDir = plistEntry.name.removeSuffix("Info.plist")
                val info = Plist.parse(zip.getInputStream(plistEntry).readBytes())
                val name = ((info["CFBundleDisplayName"] ?: info["CFBundleName"]) as? String)
                    ?.takeIf { it.isNotBlank() } ?: fallbackName

                val iconEntry = entries
                    .filter {
                        it.name.startsWith(appDir) && it.name.removePrefix(appDir).let { n ->
                            !n.contains('/') && n.endsWith(".png", true) && n.contains("icon", true)
                        }
                    }
                    .maxByOrNull { it.size }
                var hasIcon = false
                if (iconEntry != null) {
                    val bmp = IconDecoder.decode(zip.getInputStream(iconEntry).readBytes())
                    if (bmp != null) {
                        val scaled = Bitmap.createScaledBitmap(bmp, 256, 256, true)
                        iconFile(c, Game(id, name, true)).outputStream().use {
                            scaled.compress(Bitmap.CompressFormat.PNG, 100, it)
                        }
                        hasIcon = true
                    }
                }
                val game = Game(id, name, hasIcon)
                save(c, list(c) + game)
                game
            }
        } catch (e: Exception) {
            ipa.delete()
            throw e
        }
    }
}
