package com.astralhle.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.DecelerateInterpolator
import android.view.animation.PathInterpolator
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/** Home screen: empty grid of imported games, page dots and a glass dock (Add IPA, Settings, Recent app). */
class HomeView(ctx: Context) : View(ctx) {
    interface Listener {
        fun onOpenGame(g: Game, iconRect: RectF)
        fun onAddIpa()
        fun onOpenSettings(iconRect: RectF)
        fun onDeleteRequest(g: Game)
    }

    var listener: Listener? = null

    private enum class Kind { GAME, ADD, SETTINGS, RECENT }
    private class Item(val kind: Kind, val game: Game?, val label: String) {
        val rect = RectF()
        var page = 0
        var pressed = false
    }

    private val d = ctx.resources.displayMetrics.density
    private val sd = ctx.resources.displayMetrics.scaledDensity
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val bg = Paint(Paint.FILTER_BITMAP_FLAG)
    private val dim = Paint().apply { color = Color.argb(40, 0, 0, 10) }
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val art = Paint(Paint.ANTI_ALIAS_FLAG)
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 11.5f * sd; textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); setShadowLayer(3 * d, 0f, 1 * d, Color.argb(160, 0, 0, 0))
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)

    private var games: List<Game> = emptyList()
    private var recent: Game? = null
    private val bitmaps = HashMap<String, Bitmap?>()
    private var gameItems: List<Item> = emptyList()
    private var dockItems: List<Item> = emptyList()
    private val dockRect = RectF()
    private var perPage = 20
    private var page = 0
    private var pageCount = 1
    private var dragX = 0f

    private var introP = 1f
    private var pressedItem: Item? = null
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var longPressed = false
    private val longPress = Runnable {
        val it = pressedItem
        if (it != null && !moved && it.kind == Kind.GAME && it.game != null) {
            longPressed = true; it.pressed = false; pressedItem = null; invalidate(); listener?.onDeleteRequest(it.game)
        }
    }
    private var settleAnim: ValueAnimator? = null
    private val tick = object : Runnable { override fun run() { invalidate(); postDelayed(this, 15000) } }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); post(tick) }
    override fun onDetachedFromWindow() { removeCallbacks(tick); removeCallbacks(longPress); super.onDetachedFromWindow() }

    fun setData(list: List<Game>, recentGame: Game?) {
        games = list; recent = recentGame
        bitmaps.clear()
        for (g in list) if (g.hasIcon) bitmaps[g.id] = BitmapFactory.decodeFile(Library.iconFile(context, g).path)
        layoutItems(); invalidate()
    }

    /** Icons pop in one after another (used after unlocking). */
    fun playIntro() {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 780; interpolator = DecelerateInterpolator(1f)
            addUpdateListener { introP = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    fun iconRectOf(game: Game): RectF? {
        for (it in gameItems) if (it.game?.id == game.id) return RectF(it.rect)
        for (it in dockItems) if (it.kind == Kind.RECENT) return RectF(it.rect)
        return null
    }
    fun settingsRect(): RectF = RectF(dockItems.firstOrNull { it.kind == Kind.SETTINGS }?.rect ?: RectF())

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { super.onSizeChanged(w, h, ow, oh); layoutItems() }

    private fun layoutItems() {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val cellW = w / 4f
        val iconSize = min(cellW * 0.68f, 72 * d)
        val topPad = 78 * d
        val rowH = iconSize + 38 * d
        val dockAreaH = iconSize + 48 * d + 48 * d
        val rows = ((h - topPad - dockAreaH) / rowH).toInt().coerceIn(2, 6)
        perPage = 4 * rows
        pageCount = max(1, ceil(games.size / perPage.toFloat()).toInt())
        page = min(page, pageCount - 1)
        gameItems = games.mapIndexed { i, g ->
            val it = Item(Kind.GAME, g, g.name)
            it.page = i / perPage
            val idx = i % perPage
            val left = (idx % 4) * cellW + (cellW - iconSize) / 2f
            val top = topPad + (idx / 4) * rowH
            it.rect.set(left, top, left + iconSize, top + iconSize); it
        }
        val items = ArrayList<Item>()
        items += Item(Kind.ADD, null, "Add IPA")
        items += Item(Kind.SETTINGS, null, "Settings")
        recent?.let { items += Item(Kind.RECENT, it, it.name) }
        val slotW = cellW * 0.92f
        val panelW = items.size * slotW + 30 * d
        val panelH = iconSize + 52 * d
        dockRect.set((w - panelW) / 2f, h - 22 * d - panelH, (w + panelW) / 2f, h - 22 * d)
        items.forEachIndexed { i, it ->
            val cx = dockRect.left + 15 * d + slotW * (i + 0.5f)
            it.rect.set(cx - iconSize / 2f, dockRect.top + 18 * d, cx + iconSize / 2f, dockRect.top + 18 * d + iconSize)
        }
        dockItems = items
    }

    private fun introScale(index: Int, total: Int): Pair<Float, Float> {   // (scale, alpha)
        if (introP >= 1f) return Pair(1f, 1f)
        val t = ((introP * (1f + total * 0.045f)) - index * 0.045f).coerceIn(0f, 1f)
        val e = 1f - (1f - t) * (1f - t)
        return Pair(1.3f - 0.3f * e, e)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawBitmap(Wallpaper.cover(context, width, height), 0f, 0f, bg)
        c.drawRect(0f, 0f, w, h, dim)
        StatusBar.draw(c, context, w, Clock.timeText(context))
        if (games.isEmpty()) {
            label.textSize = 15 * sd
            c.drawText("No games yet", w / 2, h * 0.38f, label)
            label.textSize = 12.5f * sd
            c.drawText("Tap Add IPA below to import one", w / 2, h * 0.38f + 24 * d, label)
            label.textSize = 11.5f * sd
        }
        val total = gameItems.size + dockItems.size
        gameItems.forEachIndexed { i, it ->
            val dx = (it.page - page) * w + dragX
            if (dx > -w && dx < w) drawItem(c, it, dx, i, total)
        }
        if (pageCount > 1) {
            val gap = 15 * d; val x0 = w / 2 - gap * (pageCount - 1) / 2f; val y = dockRect.top - 18 * d
            for (i in 0 until pageCount) {
                val near = 1f - min(1f, abs(page - i - dragX / w))
                dot.color = Color.argb((90 + 150 * near).toInt(), 255, 255, 255); c.drawCircle(x0 + i * gap, y, 3.4f * d, dot)
            }
        }
        val (_, da) = introScale(gameItems.size, total)
        if (da < 1f) c.saveLayerAlpha(null, (255 * da).toInt())
        Glass.panel(c, this, dockRect, 34 * d, 46)
        if (da < 1f) c.restore()
        dockItems.forEachIndexed { i, it -> drawItem(c, it, 0f, gameItems.size + i, total) }
    }

    private fun drawItem(c: Canvas, item: Item, dx: Float, index: Int, total: Int) {
        val (s0, a) = introScale(index, total)
        val s = s0 * (if (item.pressed) 0.92f else 1f)
        val r = RectF(item.rect); r.offset(dx, 0f)
        val cx = r.centerX(); val cy = r.centerY()
        c.save()
        c.scale(s, s, cx, cy)
        if (a < 1f) c.saveLayerAlpha(RectF(r.left - 20 * d, r.top - 20 * d, r.right + 20 * d, r.bottom + 50 * d), (255 * a).toInt())
        Glass.drawShadow(c, r, d)
        val path = Glass.squircle(r)
        c.save(); c.clipPath(path)
        when (item.kind) {
            Kind.GAME, Kind.RECENT -> {
                val bmp = item.game?.let { bitmaps[it.id] ?: if (it.hasIcon) BitmapFactory.decodeFile(Library.iconFile(context, it).path).also { b -> bitmaps[it.id] = b } else null }
                if (bmp != null) c.drawBitmap(bmp, null, r, bmpPaint) else drawNeutral(c, r)
            }
            Kind.ADD -> drawAdd(c, r)
            Kind.SETTINGS -> drawGear(c, r)
        }
        c.restore()
        Glass.iconOverlay(c, r, path, d)
        if (a < 1f) c.restore()
        c.restore()
        val text = TextUtils.ellipsize(item.label, TextPaint(label), r.width() + 18 * d, TextUtils.TruncateAt.END).toString()
        if (a >= 0.99f) c.drawText(text, cx, r.bottom + 17 * d, label)
    }

    private fun gradient(r: RectF, c0: Int, c1: Int) { art.shader = LinearGradient(0f, r.top, 0f, r.bottom, c0, c1, Shader.TileMode.CLAMP); art.style = Paint.Style.FILL }

    private fun drawNeutral(c: Canvas, r: RectF) {   // game without an icon: calm glass tile, no letters
        gradient(r, Color.rgb(74, 84, 120), Color.rgb(30, 34, 58)); c.drawRect(r, art); art.shader = null
        art.color = Color.argb(200, 255, 255, 255)
        val p = Path(); val cx = r.centerX(); val cy = r.centerY(); val s = r.width() * 0.17f
        p.moveTo(cx - s * 0.7f, cy - s); p.lineTo(cx + s * 1.1f, cy); p.lineTo(cx - s * 0.7f, cy + s); p.close(); c.drawPath(p, art)
    }

    private fun drawAdd(c: Canvas, r: RectF) {
        gradient(r, Color.rgb(96, 208, 156), Color.rgb(22, 118, 112)); c.drawRect(r, art); art.shader = null
        art.color = Color.WHITE; art.style = Paint.Style.STROKE; art.strokeWidth = r.width() * 0.1f; art.strokeCap = Paint.Cap.ROUND
        val cx = r.centerX(); val cy = r.centerY(); val s = r.width() * 0.22f
        c.drawLine(cx - s, cy, cx + s, cy, art); c.drawLine(cx, cy - s, cx, cy + s, art)
        art.style = Paint.Style.FILL; art.strokeCap = Paint.Cap.BUTT
    }

    private fun drawGear(c: Canvas, r: RectF) {
        gradient(r, Color.rgb(206, 209, 217), Color.rgb(110, 114, 126)); c.drawRect(r, art); art.shader = null
        val cx = r.centerX(); val cy = r.centerY(); val s = r.width()
        art.color = Color.rgb(52, 54, 62)
        for (i in 0 until 12) {
            c.save(); c.rotate(i * 30f, cx, cy)
            c.drawRoundRect(RectF(cx - s * 0.055f, cy - s * 0.40f, cx + s * 0.055f, cy - s * 0.23f), s * 0.02f, s * 0.02f, art); c.restore()
        }
        c.drawCircle(cx, cy, s * 0.29f, art); art.color = Color.rgb(150, 154, 164); c.drawCircle(cx, cy, s * 0.12f, art)
    }

    // ---------------------------------------------------------------- touch
    private fun hit(x: Float, y: Float): Item? {
        for (it in dockItems) { val r = RectF(it.rect); r.inset(-10 * d, -10 * d); r.bottom += 18 * d; if (r.contains(x, y)) return it }
        for (it in gameItems) {
            if (it.page != page) continue
            val r = RectF(it.rect); r.inset(-8 * d, -6 * d); r.bottom += 20 * d; if (r.contains(x - dragX, y)) return it
        }
        return null
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                settleAnim?.cancel(); downX = e.x; downY = e.y; moved = false; longPressed = false
                pressedItem = hit(e.x, e.y); pressedItem?.pressed = true; invalidate()
                postDelayed(longPress, 520)
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - downX
                if (!moved && abs(dx) > slop * 1.5f && abs(dx) > abs(e.y - downY)) {
                    moved = true; removeCallbacks(longPress); pressedItem?.pressed = false; pressedItem = null
                }
                if (moved) {
                    var t = dx
                    if ((page == 0 && t > 0) || (page == pageCount - 1 && t < 0)) t *= 0.35f   // rubber band at the ends
                    dragX = t; invalidate()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPress)
                val it = pressedItem
                if (moved) settle()
                else if (!longPressed && it != null && e.actionMasked == MotionEvent.ACTION_UP && hit(e.x, e.y) === it) {
                    it.pressed = false; pressedItem = null; invalidate(); click(it); return true
                }
                it?.pressed = false; pressedItem = null; invalidate()
            }
        }
        return true
    }

    private fun click(it: Item) {
        when (it.kind) {
            Kind.GAME, Kind.RECENT -> it.game?.let { g -> listener?.onOpenGame(g, RectF(it.rect)) }
            Kind.ADD -> listener?.onAddIpa()
            Kind.SETTINGS -> listener?.onOpenSettings(RectF(it.rect))
        }
    }

    private fun settle() {
        val w = width.toFloat()
        val old = page
        if (dragX < -w / 5 && page < pageCount - 1) page++ else if (dragX > w / 5 && page > 0) page--
        dragX += (page - old) * w   // keep the picture continuous after the page index changed
        settleAnim = ValueAnimator.ofFloat(dragX, 0f).apply {
            duration = 320; interpolator = PathInterpolator(0.2f, 0f, 0f, 1f)
            addUpdateListener { dragX = it.animatedValue as Float; invalidate() }
            start()
        }
    }
}
