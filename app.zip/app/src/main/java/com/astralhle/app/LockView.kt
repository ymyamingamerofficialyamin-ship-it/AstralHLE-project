package com.astralhle.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.PathInterpolator
import kotlin.math.max
import kotlin.math.min

/** Modern lock screen: glass clock, date and a swipe-up-to-unlock gesture. */
class LockView(ctx: Context) : View(ctx) {
    interface Listener {
        fun onDrag(p: Float)            // 0..1 while the finger drags
        fun onUnlock(p: Float)          // released far enough: continue with the unlock animation
        fun onCancel()                  // released too early: lock screen springs back
    }

    var listener: Listener? = null
    private val d = ctx.resources.displayMetrics.density
    private val sd = ctx.resources.displayMetrics.scaledDensity
    private val bg = Paint(Paint.FILTER_BITMAP_FLAG)
    private val dim = Paint().apply { color = Color.argb(34, 0, 0, 10) }
    private val datePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER; textSize = 19 * sd
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); setShadowLayer(6 * d, 0f, 1 * d, Color.argb(90, 0, 0, 0))
    }
    private val clockFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; textSize = 128 * sd; typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
        style = Paint.Style.FILL_AND_STROKE; strokeWidth = 2.5f * d
    }
    private val clockEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; textSize = 128 * sd; typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
        style = Paint.Style.STROKE; strokeWidth = 1.4f * d
    }
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    private var intro = 1f
    private var startY = 0f
    private var lastY = 0f
    private var lastT = 0L
    private var velocity = 0f   // px per ms, positive = upward
    private var dragging = false
    private var springAnim: ValueAnimator? = null
    private val tick = object : Runnable { override fun run() { invalidate(); postDelayed(this, 10000) } }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); post(tick) }
    override fun onDetachedFromWindow() { removeCallbacks(tick); springAnim?.cancel(); super.onDetachedFromWindow() }

    fun playIntro() {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 900; interpolator = PathInterpolator(0.2f, 0f, 0f, 1f)
            addUpdateListener { intro = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    fun resetState() { springAnim?.cancel(); applyProgress(0f); dragging = false }

    fun applyProgress(p: Float) {
        translationY = -p * height * 0.22f
        alpha = 1f - 0.75f * p
        scaleX = 1f + 0.03f * p; scaleY = 1f + 0.03f * p
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawBitmap(Wallpaper.cover(context, width, height), 0f, 0f, bg)
        c.drawRect(0f, 0f, w, h, dim)
        StatusBar.draw(c, context, w, "AstralHLE")
        val a = (255 * intro).toInt()
        val dy = (1f - intro) * -24 * d
        datePaint.alpha = a
        c.drawText(Clock.dateText(context), w / 2, 100 * d + dy, datePaint)
        // glass clock: translucent body with a lighter edge
        val text = Clock.timeText(context)
        val y = 235 * d + dy
        clockFill.shader = LinearGradient(0f, y - 110 * d, 0f, y, Color.argb((120 * intro).toInt(), 255, 255, 255), Color.argb((40 * intro).toInt(), 255, 255, 255), Shader.TileMode.CLAMP)
        c.drawText(text, w / 2, y, clockFill)
        clockEdge.shader = LinearGradient(0f, y - 110 * d, 0f, y, Color.argb((220 * intro).toInt(), 255, 255, 255), Color.argb((90 * intro).toInt(), 255, 255, 255), Shader.TileMode.CLAMP)
        c.drawText(text, w / 2, y, clockEdge)
        bar.alpha = 215
        c.drawRoundRect(RectF(w / 2 - 66 * d, h - 20 * d, w / 2 + 66 * d, h - 15 * d), 3 * d, 3 * d, bar)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { springAnim?.cancel(); startY = e.rawY; lastY = e.rawY; lastT = e.eventTime; dragging = true; velocity = 0f }
            MotionEvent.ACTION_MOVE -> if (dragging) {
                val dy = max(0f, startY - e.rawY)
                val dt = max(1L, e.eventTime - lastT); velocity = (lastY - e.rawY) / dt; lastY = e.rawY; lastT = e.eventTime
                val p = min(1f, dy / (height * 0.5f)); applyProgress(p); listener?.onDrag(p)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (dragging) {
                dragging = false
                val dy = max(0f, startY - e.rawY); val p = min(1f, dy / (height * 0.5f))
                if (e.actionMasked == MotionEvent.ACTION_UP && (p > 0.3f || (velocity > 1.2f && p > 0.06f))) listener?.onUnlock(p) else springBack(p)
            }
        }
        return true
    }

    private fun springBack(from: Float) {
        springAnim = ValueAnimator.ofFloat(from, 0f).apply {
            duration = (260 + 320 * from).toLong(); interpolator = DecelerateInterpolator(1.8f)
            addUpdateListener { val p = it.animatedValue as Float; applyProgress(p); listener?.onDrag(p) }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                var cancelled = false
                override fun onAnimationCancel(a: android.animation.Animator) { cancelled = true }
                override fun onAnimationEnd(a: android.animation.Animator) { if (!cancelled) listener?.onCancel() }
            })
            start()
        }
    }
}
