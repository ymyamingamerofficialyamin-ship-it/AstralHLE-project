package com.astralhle.app

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream

/** Reads binary (bplist00) and XML Info.plist files. */
object Plist {
    fun parse(data: ByteArray): Map<String, Any?> {
        val isBinary = data.size > 8 && String(data, 0, 8, Charsets.US_ASCII) == "bplist00"
        return if (isBinary) Bin(data).root() else parseXml(data)
    }

    private class Bin(val d: ByteArray) {
        val offSize: Int
        val refSize: Int
        val topObj: Long
        val offTable: Long

        init {
            val t = d.size - 32
            offSize = d[t + 6].toInt() and 0xff
            refSize = d[t + 7].toInt() and 0xff
            topObj = be(t + 16, 8)
            offTable = be(t + 24, 8)
        }

        fun be(pos: Int, n: Int): Long {
            var r = 0L
            for (i in 0 until n) r = (r shl 8) or (d[pos + i].toLong() and 0xff)
            return r
        }

        @Suppress("UNCHECKED_CAST")
        fun root(): Map<String, Any?> = (obj(topObj.toInt(), 0) as? Map<String, Any?>) ?: emptyMap()

        private fun offset(i: Int): Int = be((offTable + i.toLong() * offSize).toInt(), offSize).toInt()

        private fun obj(i: Int, depth: Int): Any? {
            if (depth > 32) return null
            var p = offset(i)
            val marker = d[p].toInt() and 0xff
            val hi = marker shr 4
            val lo = marker and 0xf
            p++
            // returns (count, position of first element)
            var count = lo
            var start = p
            if ((hi == 0x5 || hi == 0x6 || hi == 0xA || hi == 0xD) && lo == 0xf) {
                val sz = 1 shl (d[p].toInt() and 0xf)
                count = be(p + 1, sz).toInt()
                start = p + 1 + sz
            }
            return when (hi) {
                0x0 -> when (lo) { 8 -> false; 9 -> true; else -> null }
                0x1 -> be(p, 1 shl lo)
                0x2 -> if (lo == 2) java.lang.Float.intBitsToFloat(be(p, 4).toInt())
                       else java.lang.Double.longBitsToDouble(be(p, 8))
                0x5 -> String(d, start, count, Charsets.US_ASCII)
                0x6 -> String(d, start, count * 2, Charsets.UTF_16BE)
                0xA -> List(count) { k -> obj(be(start + k * refSize, refSize).toInt(), depth + 1) }
                0xD -> {
                    val m = LinkedHashMap<String, Any?>()
                    for (k in 0 until count) {
                        val key = obj(be(start + k * refSize, refSize).toInt(), depth + 1) as? String ?: continue
                        m[key] = obj(be(start + (count + k) * refSize, refSize).toInt(), depth + 1)
                    }
                    m
                }
                else -> null
            }
        }
    }

    private fun parseXml(data: ByteArray): Map<String, Any?> {
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(data), null)
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG && p.name == "dict") return readDict(p)
            ev = p.next()
        }
        return emptyMap()
    }

    private fun readDict(p: XmlPullParser): Map<String, Any?> {
        val m = LinkedHashMap<String, Any?>()
        while (p.next() != XmlPullParser.END_TAG) {
            if (p.eventType == XmlPullParser.START_TAG) {
                val key = p.nextText()
                p.nextTag()
                m[key] = readValue(p)
            }
        }
        return m
    }

    private fun readArray(p: XmlPullParser): List<Any?> {
        val l = ArrayList<Any?>()
        while (p.next() != XmlPullParser.END_TAG) {
            if (p.eventType == XmlPullParser.START_TAG) l.add(readValue(p))
        }
        return l
    }

    private fun readValue(p: XmlPullParser): Any? = when (p.name) {
        "dict" -> readDict(p)
        "array" -> readArray(p)
        "string" -> p.nextText()
        "integer" -> p.nextText().trim().toLongOrNull()
        "true" -> { p.nextTag(); true }
        "false" -> { p.nextTag(); false }
        else -> { skip(p); null }
    }

    private fun skip(p: XmlPullParser) {
        var depth = 1
        while (depth > 0) {
            when (p.next()) {
                XmlPullParser.START_TAG -> depth++
                XmlPullParser.END_TAG -> depth--
            }
        }
    }
}
