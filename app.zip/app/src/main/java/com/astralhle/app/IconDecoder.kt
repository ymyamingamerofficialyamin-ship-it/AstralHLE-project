package com.astralhle.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.ByteArrayOutputStream
import java.util.zip.Inflater

/** Decodes normal PNGs and Apple's CgBI-optimised PNGs (used for icons inside IPA files). */
object IconDecoder {
    fun decode(png: ByteArray): Bitmap? {
        val isCgbi = png.size > 40 && String(png, 0, 40, Charsets.ISO_8859_1).contains("CgBI")
        if (!isCgbi) BitmapFactory.decodeByteArray(png, 0, png.size)?.let { return it }
        return try { cgbi(png) } catch (e: Exception) { null }
    }

    private fun be32(b: ByteArray, p: Int) =
        ((b[p].toInt() and 0xff) shl 24) or ((b[p + 1].toInt() and 0xff) shl 16) or
            ((b[p + 2].toInt() and 0xff) shl 8) or (b[p + 3].toInt() and 0xff)

    private fun paeth(a: Int, b: Int, c: Int): Int {
        val p = a + b - c
        val pa = Math.abs(p - a); val pb = Math.abs(p - b); val pc = Math.abs(p - c)
        return if (pa <= pb && pa <= pc) a else if (pb <= pc) b else c
    }

    private fun cgbi(b: ByteArray): Bitmap? {
        var pos = 8
        var w = 0
        var h = 0
        val idat = ByteArrayOutputStream()
        while (pos + 8 <= b.size) {
            val len = be32(b, pos)
            val type = String(b, pos + 4, 4, Charsets.US_ASCII)
            if (type == "IHDR") {
                w = be32(b, pos + 8); h = be32(b, pos + 12)
                if (b[pos + 16].toInt() != 8 || b[pos + 17].toInt() != 6) return null
            }
            if (type == "IDAT") idat.write(b, pos + 8, len)
            if (type == "IEND") break
            pos += 12 + len
        }
        if (w <= 0 || h <= 0) return null
        val inf = Inflater(true) // CgBI uses raw deflate
        inf.setInput(idat.toByteArray())
        val stride = w * 4
        val raw = ByteArray((stride + 1) * h)
        var off = 0
        while (off < raw.size) {
            val n = inf.inflate(raw, off, raw.size - off)
            if (n == 0 && (inf.finished() || inf.needsInput())) break
            off += n
        }
        inf.end()
        val out = ByteArray(stride * h)
        for (y in 0 until h) {
            val f = raw[y * (stride + 1)].toInt()
            val rs = y * (stride + 1) + 1
            val os = y * stride
            for (x in 0 until stride) {
                val rv = raw[rs + x].toInt() and 0xff
                val a = if (x >= 4) out[os + x - 4].toInt() and 0xff else 0
                val up = if (y > 0) out[os - stride + x].toInt() and 0xff else 0
                val c = if (x >= 4 && y > 0) out[os - stride + x - 4].toInt() and 0xff else 0
                val v = when (f) {
                    1 -> rv + a
                    2 -> rv + up
                    3 -> rv + ((a + up) shr 1)
                    4 -> rv + paeth(a, up, c)
                    else -> rv
                }
                out[os + x] = v.toByte()
            }
        }
        val px = IntArray(w * h)
        for (i in 0 until w * h) {
            // CgBI stores BGRA with premultiplied alpha
            val bl = out[i * 4].toInt() and 0xff
            val g = out[i * 4 + 1].toInt() and 0xff
            val r = out[i * 4 + 2].toInt() and 0xff
            val a = out[i * 4 + 3].toInt() and 0xff
            val rr = if (a in 1..254) minOf(255, r * 255 / a) else r
            val gg = if (a in 1..254) minOf(255, g * 255 / a) else g
            val bb = if (a in 1..254) minOf(255, bl * 255 / a) else bl
            px[i] = (a shl 24) or (rr shl 16) or (gg shl 8) or bb
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }
}
