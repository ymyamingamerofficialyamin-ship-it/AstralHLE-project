package com.astralhle.app

import android.content.Context
import android.graphics.*
import android.os.Build
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/** Wallpaper (cover-cropped to the screen) and a pre-blurred copy used behind glass panels. */
object Wallpaper {
    private var cover: Bitmap? = null
    private var blurred: Bitmap? = null
    private var cw = 0
    private var ch = 0

    private fun build(ctx: Context, w: Int, h: Int) {
        if (cover != null && cw == w && ch == h) return
        val src = BitmapFactory.decodeResource(ctx.resources, R.drawable.wallpaper)
        val s = max(w.toFloat() / src.width, h.toFloat() / src.height)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val m = Matrix(); m.postScale(s, s); m.postTranslate((w - src.width * s) / 2f, (h - src.height * s) / 2f)
        Canvas(out).drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))
        if (src !== out) src.recycle()
        cover = out; cw = w; ch = h
        // blurred copy: shrink, box-blur a few times, enlarge; slightly brighter and more saturated like glass
        val sw = max(8, w / 10); val sh = max(8, h / 10)
        val small = Bitmap.createScaledBitmap(out, sw, sh, true)
        val px = IntArray(sw * sh); small.getPixels(px, 0, sw, 0, 0, sw, sh)
        repeat(3) { boxBlur(px, sw, sh, 3) }
        val blurSmall = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888); blurSmall.setPixels(px, 0, sw, 0, 0, sw, sh)
        val cm = ColorMatrix(); cm.setSaturation(1.2f)
        val br = ColorMatrix(floatArrayOf(1.25f, 0f, 0f, 0f, 6f, 0f, 1.25f, 0f, 0f, 6f, 0f, 0f, 1.25f, 0f, 6f, 0f, 0f, 0f, 1f, 0f))
        cm.postConcat(br)
        val tinted = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        Canvas(tinted).drawBitmap(blurSmall, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(cm) })
        blurred = Bitmap.createScaledBitmap(tinted, w, h, true)
    }

    fun cover(ctx: Context, w: Int, h: Int): Bitmap { build(ctx, w, h); return cover!! }
    fun blurred(ctx: Context, w: Int, h: Int): Bitmap { build(ctx, w, h); return blurred!! }

    private fun boxBlur(px: IntArray, w: Int, h: Int, r: Int) {
        val tmp = IntArray(px.size)
        for (y in 0 until h) blurLine(px, tmp, y * w, 1, w, r)
        for (x in 0 until w) blurLine(tmp, px, x, w, h, r)
    }

    private fun blurLine(src: IntArray, dst: IntArray, start: Int, step: Int, n: Int, r: Int) {
        var sa = 0; var sr = 0; var sg = 0; var sb = 0
        val div = 2 * r + 1
        for (i in -r..r) {
            val p = src[start + step * min(max(i, 0), n - 1)]
            sa += p ushr 24; sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255
        }
        for (i in 0 until n) {
            dst[start + step * i] = ((sa / div) shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
            val add = src[start + step * min(i + r + 1, n - 1)]
            val rem = src[start + step * max(i - r, 0)]
            sa += (add ushr 24) - (rem ushr 24); sr += ((add shr 16) and 255) - ((rem shr 16) and 255)
            sg += ((add shr 8) and 255) - ((rem shr 8) and 255); sb += (add and 255) - (rem and 255)
        }
    }
}

object Glass {
    private val loc = IntArray(2)
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val unit: Path = Path().also { p ->
        val n = 5.0; val steps = 72
        for (i in 0..steps) {
            val t = 2.0 * Math.PI * i / steps
            val c = cos(t); val s = sin(t)
            val x = (if (c >= 0) 1.0 else -1.0) * abs(c).pow(2.0 / n)
            val y = (if (s >= 0) 1.0 else -1.0) * abs(s).pow(2.0 / n)
            if (i == 0) p.moveTo(x.toFloat(), y.toFloat()) else p.lineTo(x.toFloat(), y.toFloat())
        }
        p.close()
    }

    fun squircle(rect: RectF): Path {
        val m = Matrix(); m.postScale(rect.width() / 2f, rect.height() / 2f); m.postTranslate(rect.centerX(), rect.centerY())
        val out = Path(); unit.transform(m, out); return out
    }

    private fun rimShader(r: RectF, a1: Int, a2: Int, a3: Int) = LinearGradient(
        r.left, r.top, r.right, r.bottom,
        intArrayOf(Color.argb(a1, 255, 255, 255), Color.argb(a2, 255, 255, 255), Color.argb(a3, 255, 255, 255)),
        floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)

    /** Frosted glass panel: blurred wallpaper + tint + edge light + top highlight. */
    fun panel(c: Canvas, v: View, rect: RectF, radius: Float, tint: Int = 40, path: Path? = null) {
        val d = v.resources.displayMetrics.density
        val root = v.rootView
        val sw = if (root.width > 0) root.width else v.resources.displayMetrics.widthPixels
        val sh = if (root.height > 0) root.height else v.resources.displayMetrics.heightPixels
        val blur = Wallpaper.blurred(v.context, sw, sh)
        v.getLocationInWindow(loc)
        val shape = path ?: Path().apply { addRoundRect(rect, radius, radius, Path.Direction.CW) }
        c.save()
        c.clipPath(shape)
        c.drawBitmap(blur, null, RectF(-loc[0].toFloat(), -loc[1].toFloat(), -loc[0].toFloat() + sw, -loc[1].toFloat() + sh), bmpPaint)
        fill.shader = null; fill.color = Color.argb(tint, 232, 232, 255); c.drawRect(rect, fill)
        val bandH = min(rect.height() * 0.5f, 64 * d)
        fill.shader = LinearGradient(0f, rect.top, 0f, rect.top + bandH, Color.argb(52, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
        c.drawRect(rect.left, rect.top, rect.right, rect.top + bandH, fill)
        fill.shader = LinearGradient(0f, rect.bottom - bandH * 0.6f, 0f, rect.bottom, Color.argb(0, 255, 255, 255), Color.argb(18, 255, 255, 255), Shader.TileMode.CLAMP)
        c.drawRect(rect.left, rect.bottom - bandH * 0.6f, rect.right, rect.bottom, fill)
        fill.shader = null
        // soft inner glow along the edge
        for ((w, a) in listOf(Pair(10f, 10), Pair(6f, 18), Pair(3f, 30))) {
            stroke.shader = rimShader(rect, a * 3, a / 2, a * 2); stroke.strokeWidth = w * d; c.drawPath(shape, stroke)
        }
        c.restore()
        stroke.shader = rimShader(rect, 215, 26, 130); stroke.strokeWidth = 1.3f * d
        c.drawPath(shape, stroke)
        stroke.shader = null
    }

    /** Glass edge, glow and highlight drawn on top of an app icon. */
    fun iconOverlay(c: Canvas, rect: RectF, path: Path, d: Float) {
        c.save(); c.clipPath(path)
        fill.shader = LinearGradient(0f, rect.top, 0f, rect.top + rect.height() * 0.5f, Color.argb(66, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
        c.drawRect(rect.left, rect.top, rect.right, rect.top + rect.height() * 0.5f, fill)
        fill.shader = LinearGradient(0f, rect.bottom - rect.height() * 0.3f, 0f, rect.bottom, Color.argb(0, 255, 255, 255), Color.argb(34, 255, 255, 255), Shader.TileMode.CLAMP)
        c.drawRect(rect.left, rect.bottom - rect.height() * 0.3f, rect.right, rect.bottom, fill)
        fill.shader = null
        for ((w, a) in listOf(Pair(8f, 12), Pair(4f, 24), Pair(2f, 40))) {
            stroke.shader = rimShader(rect, a * 3, a / 2, a * 2); stroke.strokeWidth = w * d; c.drawPath(path, stroke)
        }
        c.restore()
        stroke.shader = rimShader(rect, 230, 30, 150); stroke.strokeWidth = 1.4f * d
        c.drawPath(path, stroke); stroke.shader = null
    }

    fun drawShadow(c: Canvas, rect: RectF, d: Float) {
        fill.shader = null; fill.color = Color.argb(70, 0, 0, 0)
        val r = RectF(rect.left, rect.top + 4 * d, rect.right, rect.bottom + 4 * d)
        c.drawPath(squircle(r), fill)
    }
}

/** Real-time blur on Android 12+ (older versions just fade and zoom). */
object Fx {
    fun blur(v: View, radius: Float) {
        if (Build.VERSION.SDK_INT < 31) return
        if (radius < 0.5f) v.setRenderEffect(null)
        else v.setRenderEffect(android.graphics.RenderEffect.createBlurEffect(radius, radius, Shader.TileMode.CLAMP))
    }
}

object StatusBar {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)

    fun draw(c: Canvas, ctx: Context, w: Float, left: String) {
        val d = ctx.resources.displayMetrics.density
        val sd = ctx.resources.displayMetrics.scaledDensity
        val cy = 22 * d
        p.color = Color.WHITE; p.textSize = 14 * sd; p.textAlign = Paint.Align.LEFT
        c.drawText(left, 20 * d, cy + 5 * d, p)
        val (pct, charging) = BatteryInfo.read(ctx)
        val bw = 25 * d; val bh = 12 * d; val right = w - 18 * d; val x0 = right - bw
        line.color = Color.argb(200, 255, 255, 255); line.strokeWidth = 1.2f * d
        c.drawRoundRect(RectF(x0, cy - bh / 2, right, cy + bh / 2), 3.5f * d, 3.5f * d, line)
        fillP.color = if (charging) Color.rgb(90, 220, 120) else if (pct <= 20) Color.rgb(255, 90, 80) else Color.WHITE
        c.drawRoundRect(RectF(x0 + 1.8f * d, cy - bh / 2 + 1.8f * d, x0 + 1.8f * d + (bw - 3.6f * d) * pct / 100f, cy + bh / 2 - 1.8f * d), 2f * d, 2f * d, fillP)
        fillP.color = Color.argb(200, 255, 255, 255); c.drawRoundRect(RectF(right + 1.5f * d, cy - 2.5f * d, right + 3f * d, cy + 2.5f * d), 1f * d, 1f * d, fillP)
        p.textAlign = Paint.Align.RIGHT; p.textSize = 13 * sd; p.color = Color.WHITE
        c.drawText("$pct%", x0 - 6 * d - (if (charging) 10 * d else 0f), cy + 4.5f * d, p)
        if (charging) {   // small lightning bolt
            val bx = x0 - 9 * d; val path = Path()
            path.moveTo(bx + 3 * d, cy - 6 * d); path.lineTo(bx - 2 * d, cy + 1 * d); path.lineTo(bx + 1 * d, cy + 1 * d)
            path.lineTo(bx - 1 * d, cy + 7 * d); path.lineTo(bx + 4.5f * d, cy - 1 * d); path.lineTo(bx + 1.5f * d, cy - 1 * d); path.close()
            fillP.color = Color.rgb(90, 220, 120); c.drawPath(path, fillP)
        }
        p.textAlign = Paint.Align.LEFT
    }
}
