package com.astralhle.app

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.Toast

/** Clips a view to rounded corners (used while the Settings window grows out of its icon). */
object Round {
    fun set(v: View, radius: Float) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, view.width, view.height, radius) }
        }
        v.clipToOutline = true; v.invalidateOutline()
    }
    fun clear(v: View) { v.clipToOutline = false; v.outlineProvider = ViewOutlineProvider.BACKGROUND }
}

/** The game "opens out of" its icon: a squircle grows from the icon to the full screen and fades to black. */
class LaunchOverlay(ctx: Context, private val icon: RectF, private val bmp: Bitmap?) : View(ctx) {
    var e = 0f
        set(v) { field = v; invalidate() }
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    override fun onDraw(c: Canvas) {
        if (e <= 0.001f) return
        val full = RectF(0f, 0f, width.toFloat(), height.toFloat())
        val r = RectF(icon.left + (full.left - icon.left) * e, icon.top + (full.top - icon.top) * e, icon.right + (full.right - icon.right) * e, icon.bottom + (full.bottom - icon.bottom) * e)
        val path = Glass.squircle(r)
        c.save(); c.clipPath(path)
        p.color = Color.BLACK; p.alpha = (255 * minOf(1f, e * 2.2f)).toInt(); c.drawRect(r, p)
        if (bmp != null) {
            val a = (255 * (1f - minOf(1f, e * 1.6f))).toInt()
            if (a > 0) { bp.alpha = a; c.drawBitmap(bmp, null, r, bp) }
        }
        c.restore()
    }
}

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var home: HomeView
    private lateinit var lock: LockView
    private var settings: SettingsView? = null
    private var overlay: LaunchOverlay? = null
    private var locked = true
    private var launching = false
    private var returningFromGame = false
    private var lastIconRect: RectF? = null
    private var lastGame: Game? = null
    private val reqIpa = 11
    private val smooth = PathInterpolator(0.2f, 0f, 0f, 1f)
    private val dens get() = resources.displayMetrics.density

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply { layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES }
        }
        root = FrameLayout(this); root.setBackgroundColor(Color.BLACK); setContentView(root)
        home = HomeView(this); lock = LockView(this)
        root.addView(home, ViewGroup.LayoutParams(-1, -1)); root.addView(lock, ViewGroup.LayoutParams(-1, -1))
        home.listener = object : HomeView.Listener {
            override fun onOpenGame(g: Game, iconRect: RectF) = openGame(g, iconRect)
            override fun onAddIpa() = pickIpa()
            override fun onOpenSettings(iconRect: RectF) = openSettings(iconRect)
            override fun onDeleteRequest(g: Game) = confirmDelete(g)
        }
        lock.listener = object : LockView.Listener {
            override fun onDrag(p: Float) { if (p > 0.001f) { home.visibility = View.VISIBLE; home.alpha = 0.95f * p; home.scaleX = 1.07f - 0.07f * p; home.scaleY = home.scaleX } else if (locked) home.visibility = View.INVISIBLE }
            override fun onUnlock(p: Float) = unlock()
            override fun onCancel() { if (locked) home.visibility = View.INVISIBLE }
        }
        locked = Prefs.lockScreen(this)
        if (locked) { home.visibility = View.INVISIBLE; lock.playIntro() } else lock.visibility = View.GONE
        refresh()
    }

    override fun onResume() {
        super.onResume(); hideSystemUi(); refresh()
        if (returningFromGame) {
            returningFromGame = false
            val ov = overlay; val rect = lastIconRect
            if (ov != null && rect != null) {
                ValueAnimator.ofFloat(1f, 0f).apply {
                    duration = 420; interpolator = smooth
                    addUpdateListener { ov.e = it.animatedValue as Float; home.scaleX = 0.94f + 0.06f * (1f - ov.e); home.scaleY = home.scaleX; home.alpha = 0.6f + 0.4f * (1f - ov.e) }
                    addListener(object : AnimatorListenerAdapter() { override fun onAnimationEnd(a: Animator) { root.removeView(ov); overlay = null; launching = false; home.scaleX = 1f; home.scaleY = 1f; home.alpha = 1f; Fx.blur(home, 0f) } })
                    start()
                }
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus) hideSystemUi() }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    }

    private fun refresh() = home.setData(Library.list(this), Library.find(this, Prefs.recentId(this)))

    // ---------------------------------------------------------------- lock <-> home
    private fun unlock() {
        if (!locked) return
        locked = false
        home.visibility = View.VISIBLE; home.playIntro()
        val a0 = home.alpha; val s0 = if (home.scaleX < 1f) 1.07f else home.scaleX
        val lAlpha = lock.alpha; val lTy = lock.translationY; val lSc = lock.scaleX
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 620; interpolator = smooth
            addUpdateListener {
                val e = it.animatedValue as Float
                home.alpha = a0 + (1f - a0) * minOf(1f, e * 1.4f); home.scaleX = s0 + (1f - s0) * e; home.scaleY = home.scaleX
                Fx.blur(home, 26f * (1f - e))
                lock.alpha = lAlpha * (1f - minOf(1f, e * 1.6f)); lock.translationY = lTy + (-lock.height * 0.30f - lTy) * e
                lock.scaleX = lSc + (1.08f - lSc) * e; lock.scaleY = lock.scaleX
                Fx.blur(lock, 28f * e)
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) { lock.visibility = View.GONE; lock.resetState(); Fx.blur(lock, 0f); Fx.blur(home, 0f); home.alpha = 1f; home.scaleX = 1f; home.scaleY = 1f }
            })
            start()
        }
    }

    private fun lockNow() {
        if (locked || !Prefs.lockScreen(this)) return
        locked = true
        lock.resetState(); lock.visibility = View.VISIBLE; lock.alpha = 0f; lock.scaleX = 0.96f; lock.scaleY = 0.96f; lock.playIntro()
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 460; interpolator = smooth
            addUpdateListener {
                val e = it.animatedValue as Float
                lock.alpha = e; lock.scaleX = 0.96f + 0.04f * e; lock.scaleY = lock.scaleX
                home.alpha = 1f - e; home.scaleX = 1f + 0.06f * e; home.scaleY = home.scaleX
            }
            addListener(object : AnimatorListenerAdapter() { override fun onAnimationEnd(a: Animator) { if (locked) home.visibility = View.INVISIBLE } })
            start()
        }
    }

    // ---------------------------------------------------------------- Settings window
    private fun openSettings(iconRect: RectF) {
        if (settings != null) return
        val s = SettingsView(this) { closeSettings() }
        settings = s; root.addView(s, ViewGroup.LayoutParams(-1, -1))
        val w = root.width.toFloat(); val s0 = iconRect.width() / w
        s.pivotX = iconRect.centerX(); s.pivotY = iconRect.centerY(); s.scaleX = s0; s.scaleY = s0; s.alpha = 0f
        animateSettings(s, iconRect, 0f, 1f) { Round.clear(s); s.scaleX = 1f; s.scaleY = 1f }
    }

    private fun closeSettings() {
        val s = settings ?: return
        settings = null
        val rect = home.settingsRect()
        s.pivotX = rect.centerX(); s.pivotY = rect.centerY()
        animateSettings(s, rect, 1f, 0f) { root.removeView(s); Fx.blur(home, 0f); home.scaleX = 1f; home.scaleY = 1f; home.alpha = 1f; refresh() }
    }

    private fun animateSettings(s: SettingsView, rect: RectF, from: Float, to: Float, end: () -> Unit) {
        val w = root.width.toFloat(); val s0 = rect.width() / w; val corner = 16 * dens
        ValueAnimator.ofFloat(from, to).apply {
            duration = if (to > from) 480 else 380; interpolator = smooth
            addUpdateListener {
                val e = it.animatedValue as Float
                val sc = s0 + (1f - s0) * e
                s.scaleX = sc; s.scaleY = sc; s.alpha = minOf(1f, e * 3f)
                Round.set(s, corner * (1f - e) / maxOf(sc, 0.05f))
                home.scaleX = 1f - 0.06f * e; home.scaleY = home.scaleX; Fx.blur(home, 18f * e)
            }
            addListener(object : AnimatorListenerAdapter() { override fun onAnimationEnd(a: Animator) { end() } })
            start()
        }
    }

    // ---------------------------------------------------------------- games
    private fun openGame(g: Game, iconRect: RectF) {
        if (launching) return
        launching = true; lastIconRect = RectF(iconRect); lastGame = g
        Prefs.setStr(this, "recent", g.id)
        val bmp = if (g.hasIcon) BitmapFactory.decodeFile(Library.iconFile(this, g).path) else null
        val ov = LaunchOverlay(this, iconRect, bmp); overlay = ov
        root.addView(ov, ViewGroup.LayoutParams(-1, -1))
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 420; interpolator = smooth
            addUpdateListener { ov.e = it.animatedValue as Float; home.scaleX = 1f - 0.06f * ov.e; home.scaleY = home.scaleX; home.alpha = 1f - 0.4f * ov.e }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) {
                    returningFromGame = true
                    startActivity(Intent(this@MainActivity, GameActivity::class.java).putExtra("id", g.id).putExtra("name", g.name))
                    overridePendingTransition(0, 0)
                }
            })
            start()
        }
    }

    private fun confirmDelete(g: Game) {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert).setTitle("Delete \"${g.name}\"?")
            .setMessage("The imported IPA file will be removed from AstralHLE.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ -> Library.remove(this, g); refresh() }.show()
    }

    // ---------------------------------------------------------------- Add IPA
    private fun pickIpa() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }, reqIpa)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqIpa || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        var fallback = "Game"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && idx >= 0) fallback = c.getString(idx).removeSuffix(".ipa")
        }
        Toast.makeText(this, "Importing...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val g = Library.import(this, uri, fallback)
                runOnUiThread { refresh(); Toast.makeText(this, "Added ${g.name}", Toast.LENGTH_SHORT).show() }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, e.message ?: "Could not import this file", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            settings != null -> closeSettings()
            !locked && Prefs.lockScreen(this) -> lockNow()
            else -> super.onBackPressed()
        }
    }
}
