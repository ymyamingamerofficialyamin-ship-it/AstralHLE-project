package com.astralhle.app

import android.app.Activity
import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import android.util.Log
import android.widget.Toast
import java.io.File
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Keeps the game picture in its original 3:2 shape (Minimal) or fills the screen (Full). */
private class Letterbox(ctx: Context, private val full: Boolean, private val portrait: Boolean) : ViewGroup(ctx) {
    override fun onMeasure(wms: Int, hms: Int) {
        val w = MeasureSpec.getSize(wms); val h = MeasureSpec.getSize(hms)
        setMeasuredDimension(w, h)
        val c = getChildAt(0) ?: return
        var cw = w; var ch = h
        if (!full) {
            val aspect = if (portrait) 2f / 3f else 1.5f   // width / height of the original iPhone screen
            cw = w; ch = (w / aspect).toInt()
            if (ch > h) { ch = h; cw = (h * aspect).toInt() }
        }
        c.measure(MeasureSpec.makeMeasureSpec(cw, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(ch, MeasureSpec.EXACTLY))
    }
    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val c = getChildAt(0) ?: return
        val x = ((r - l) - c.measuredWidth) / 2; val y = ((b - t) - c.measuredHeight) / 2
        c.layout(x, y, x + c.measuredWidth, y + c.measuredHeight)
    }
}

/** Game screen background: the game's own launch image (or its icon) and a thin moving bar while the core works. */
private class SplashView(ctx: Context, private val iconBmp: Bitmap?, private val onFrame: () -> Unit) : View(ctx) {
    var splash: Bitmap? = null
    var finished = false
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val start = System.nanoTime()
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.shader = LinearGradient(0f, 0f, 0f, h, Color.rgb(16, 18, 36), Color.rgb(6, 7, 16), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p); p.shader = null
        val s = splash
        if (s != null) {
            val k = min(w / s.width, h / s.height); val dw = s.width * k; val dh = s.height * k
            c.drawBitmap(s, null, RectF((w - dw) / 2, (h - dh) / 2, (w + dw) / 2, (h + dh) / 2), p)
        } else if (iconBmp != null) {
            val side = min(w, h) * 0.34f
            val r = RectF(w / 2 - side / 2, h / 2 - side / 2 - 10 * d, w / 2 + side / 2, h / 2 + side / 2 - 10 * d)
            val path = Glass.squircle(r)
            c.save(); c.clipPath(path); c.drawBitmap(iconBmp, null, r, p); c.restore()
            Glass.iconOverlay(c, r, path, d)
        }
        if (!finished) {   // a thin bar so the screen visibly lives while the core works
            val t = (((System.nanoTime() - start) / 1.0e9) % 1.6 / 1.6).toFloat()
            val bw = w * 0.5f; val x = -bw + (w + bw) * t
            p.color = Color.argb(200, 130, 195, 255)
            c.drawRoundRect(RectF(max(0f, x), h - 6 * d, min(w, x + bw), h - 3 * d), 3 * d, 3 * d, p)
        }
        onFrame(); postInvalidateOnAnimation()
    }
}

/** Small round glass button (like AssistiveTouch). Drag it anywhere; tap it to get the Close option. */
private class FloatingButton(ctx: Context, private val onTap: () -> Unit, private val onMoved: () -> Unit) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var downX = 0f; private var downY = 0f; private var startX = 0f; private var startY = 0f; private var dragged = false
    override fun onDraw(c: Canvas) {
        val r = RectF(0f, 0f, width.toFloat(), height.toFloat())
        Glass.panel(c, this, r, width / 2f, 48)
        p.style = Paint.Style.FILL; p.color = Color.argb(120, 255, 255, 255); c.drawCircle(width / 2f, height / 2f, width * 0.26f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f * d; p.color = Color.argb(220, 255, 255, 255); c.drawCircle(width / 2f, height / 2f, width * 0.26f, p)
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val parentView = parent as View
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startX = x; startY = y; dragged = false; animate().scaleX(0.92f).scaleY(0.92f).setDuration(90).start() }
            MotionEvent.ACTION_MOVE -> {
                if (!dragged && (abs(e.rawX - downX) > 8 * d || abs(e.rawY - downY) > 8 * d)) dragged = true
                if (dragged) {
                    x = (startX + e.rawX - downX).coerceIn(0f, (parentView.width - width).toFloat())
                    y = (startY + e.rawY - downY).coerceIn(0f, (parentView.height - height).toFloat())
                    onMoved()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                animate().scaleX(1f).scaleY(1f).setDuration(140).start()
                if (!dragged && e.actionMasked == MotionEvent.ACTION_UP) onTap() else onMoved()
            }
        }
        return true
    }
}

private class GlassLabel(ctx: Context, private val text: String, private val onClick: () -> Unit) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; textSize = 15 * ctx.resources.displayMetrics.scaledDensity; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) }
    override fun onDraw(c: Canvas) {
        Glass.panel(c, this, RectF(0f, 0f, width.toFloat(), height.toFloat()), height / 2f, 52)
        c.drawText(text, width / 2f, height / 2f + 5 * d, p)
    }
    override fun onTouchEvent(e: MotionEvent): Boolean { if (e.actionMasked == MotionEvent.ACTION_UP) onClick(); return true }
}

class GameActivity : Activity() {
    private lateinit var stage: FrameLayout
    private lateinit var surface: SplashView
    private lateinit var report: TextView
    private var fpsView: TextView? = null
    private var frames = 0
    private var lastTs = System.nanoTime()
    private var button: FloatingButton? = null
    private var menu: GlassLabel? = null
    private var closing = false
    private var fullReport = ""
    private val smooth = PathInterpolator(0.2f, 0f, 0f, 1f)
    private val dens get() = resources.displayMetrics.density

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra("id"); val name = intent.getStringExtra("name") ?: "Game"
        val scale = Prefs.scale(this); val backend = GpuPolicy.resolve(this)
        val game = Library.find(this, id)
        val portrait = game?.let { Library.orientationOf(this, it) } ?: false   // the IPA says which way the game is played
        requestedOrientation = if (portrait) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        val baseW = if (portrait) 320 else 480; val baseH = if (portrait) 480 else 320   // original iPhone resolution

        // Plain Canvas view (no SurfaceView): it always sits UNDER the report, FPS counter and floating button.
        val iconBmp = if (game != null && game.hasIcon) BitmapFactory.decodeFile(Library.iconFile(this, game).path) else null
        surface = SplashView(this, iconBmp) { countFrame() }
        val area = FrameLayout(this); area.addView(surface, FrameLayout.LayoutParams(-1, -1))
        val box = Letterbox(this, Prefs.displayFull(this), portrait); box.addView(area)

        stage = FrameLayout(this); stage.setBackgroundColor(Color.BLACK)
        stage.addView(box, FrameLayout.LayoutParams(-1, -1))

        report = TextView(this).apply {
            setTextColor(Color.argb(235, 255, 255, 255)); textSize = 10.5f; typeface = Typeface.MONOSPACE
            setPadding((12 * dens).toInt(), (10 * dens).toInt(), (12 * dens).toInt(), (10 * dens).toInt())
            text = "$name\n\nStarting the AstralHLE core..."
        }
        val sv = ScrollView(this).apply {
            background = GradientDrawable().apply { setColor(Color.argb(150, 6, 8, 20)); cornerRadius = 16 * dens }
            addView(report)
        }
        stage.addView(sv, FrameLayout.LayoutParams((340 * dens).toInt(), (230 * dens).toInt(), Gravity.START or Gravity.CENTER_VERTICAL).apply { leftMargin = (18 * dens).toInt() })

        if (Prefs.fps(this)) {
            fpsView = TextView(this).apply {
                setTextColor(Color.rgb(124, 255, 124)); textSize = 13f; text = "FPS: --"; typeface = Typeface.MONOSPACE
                background = GradientDrawable().apply { setColor(Color.argb(150, 0, 0, 0)); cornerRadius = 8 * dens }
                setPadding((10 * dens).toInt(), (5 * dens).toInt(), (10 * dens).toInt(), (5 * dens).toInt())
            }
            val g = when (Prefs.fpsCorner(this)) { 0 -> Gravity.TOP or Gravity.START; 1 -> Gravity.TOP or Gravity.END; 2 -> Gravity.BOTTOM or Gravity.END; else -> Gravity.BOTTOM or Gravity.START }
            stage.addView(fpsView, FrameLayout.LayoutParams(-2, -2, g).apply { setMargins((14 * dens).toInt(), (14 * dens).toInt(), (14 * dens).toInt(), (14 * dens).toInt()) })
        }

        val copy = GlassLabel(this, "Copy report") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("AstralHLE report", if (fullReport.isEmpty()) report.text.toString() else fullReport))
            Toast.makeText(this, "Report copied", Toast.LENGTH_SHORT).show()
        }
        stage.addView(copy, FrameLayout.LayoutParams((150 * dens).toInt(), (44 * dens).toInt(), Gravity.START or Gravity.BOTTOM).apply { leftMargin = (18 * dens).toInt(); bottomMargin = (16 * dens).toInt() })
        val bs = (52 * dens).toInt()
        val btn = FloatingButton(this, { toggleMenu() }, { positionMenu(); savePosition() })
        button = btn
        stage.addView(btn, FrameLayout.LayoutParams(bs, bs))
        stage.setOnTouchListener { _, e -> if (e.actionMasked == MotionEvent.ACTION_DOWN) hideMenu(); false }
        setContentView(stage)
        stage.post {
            btn.x = Prefs.getInt(this, "fbx1000", 940) / 1000f * (stage.width - bs)
            btn.y = Prefs.getInt(this, "fby1000", 400) / 1000f * (stage.height - bs)
        }
        // open: the game fades and grows in
        stage.alpha = 0f; stage.scaleX = 0.92f; stage.scaleY = 0.92f
        stage.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(320).setInterpolator(smooth).start()
        stage.postDelayed({ if (!closing) { stage.alpha = 1f; stage.scaleX = 1f; stage.scaleY = 1f } }, 700)

        Thread {
            var text: String
            try {
                val sp = if (game != null) Library.splashOf(this, game) else null
                if (sp != null) runOnUiThread { surface.splash = sp }
                val exe = if (game != null) Library.extractExecutable(this, game) else null
                text = when {
                    !AstralCore.ensureLoaded() -> "The native core could not be loaded: " + AstralCore.error()
                    exe == null -> "Could not read the game's executable from the IPA."
                    else -> AstralCore.run(exe.path, Options.deviceIds[Prefs.deviceIndex(this)], 20_000_000L, Ram.limitMb(this))
                }
                exe?.delete()
            } catch (t: Throwable) {
                text = "ERROR while running the core:\n" + t.toString()
            }
            val note = "\nResolution: ${baseW * scale} x ${baseH * scale}, graphics: " + (if (backend == Backend.VULKAN) "Vulkan selected (renderer not written yet, OpenGL ES used)" else "OpenGL ES 2.0") +
                "\nNext step: Objective-C runtime and Foundation, then UIKit and OpenGL ES, so the game can draw its first frame."
            val full = "$name\n\nCore report (the game cannot draw yet, rendering is the next step):\n\n$text$note"
            try { File(filesDir, "last_report.txt").writeText(full) } catch (e: Exception) { }
            runOnUiThread { report.text = full; fullReport = full; surface.finished = true }
        }.start()
    }

    private fun savePosition() {
        val b = button ?: return
        val w = (stage.width - b.width).coerceAtLeast(1); val h = (stage.height - b.height).coerceAtLeast(1)
        Prefs.setInt(this, "fbx1000", (b.x / w * 1000).toInt()); Prefs.setInt(this, "fby1000", (b.y / h * 1000).toInt())
    }

    private fun toggleMenu() { if (menu != null) hideMenu() else showMenu() }

    private fun showMenu() {
        val b = button ?: return
        val m = GlassLabel(this, "Close app") { closeApp() }
        menu = m
        stage.addView(m, FrameLayout.LayoutParams((130 * dens).toInt(), (44 * dens).toInt()))
        positionMenu(); m.alpha = 0f; m.scaleX = 0.8f; m.scaleY = 0.8f
        m.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(200).setInterpolator(smooth).start()
        b.bringToFront()
    }

    private fun positionMenu() {
        val b = button ?: return; val m = menu ?: return
        val mw = (130 * dens); val gap = 10 * dens
        m.x = if (b.x + b.width / 2f > stage.width / 2f) b.x - mw - gap else b.x + b.width + gap
        m.y = b.y + (b.height - 44 * dens) / 2f
    }

    private fun hideMenu() {
        val m = menu ?: return; menu = null
        m.animate().alpha(0f).scaleX(0.8f).scaleY(0.8f).setDuration(140).withEndAction { stage.removeView(m) }.start()
    }

    private fun closeApp() {
        if (closing) return
        closing = true; hideMenu()
        stage.animate().alpha(0f).scaleX(0.9f).scaleY(0.9f).setDuration(260).setInterpolator(smooth).withEndAction { finish(); overridePendingTransition(0, 0) }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { closeApp() }

    private fun countFrame() {
        frames++
        val now = System.nanoTime()
        if (now - lastTs >= 1_000_000_000L) {
            val fps = frames * 1.0e9 / (now - lastTs); frames = 0; lastTs = now
            fpsView?.text = "FPS: %.0f".format(fps)
        }
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    }

}
